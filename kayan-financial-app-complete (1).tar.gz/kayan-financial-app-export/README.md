# تطبيق كيان للإدارة المالية 💰

نظام إدارة مالية شامل ومتطور باللغة العربية والإنجليزية، مصمم خصيصاً للشركات الصغيرة والمتوسطة في السودان.

![Kayan Financial App](https://img.shields.io/badge/Version-2.0-blue.svg)
![React](https://img.shields.io/badge/React-18.0-61dafb.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## 🌟 المميزات الرئيسية

### 🌍 دعم اللغتين
- **العربية والإنجليزية** مع تبديل فوري
- **دعم كامل للاتجاه RTL** للغة العربية
- **عملة الجنيه السوداني (SDG)** مع التنسيق المحلي

### 💼 إدارة شاملة للأعمال
- **إدارة الفواتير** مع حساب الأرباح التلقائي
- **إدارة العملاء** مع تحليلات مفصلة
- **إدارة المنتجات** مع تتبع التكاليف والأرباح
- **إدارة الموردين** منفصلة عن حسابات الأرباح
- **إدارة المصروفات** مع تصنيف شخصي/عائلي

### 💰 نظام مالي متقدم
- **حساب الأرباح التلقائي** لكل بند في الفاتورة
- **الدفع الجزئي** مع تتبع المبالغ المتبقية
- **ربط بالحسابات البنكية** (الخرطوم، أمدرمان، نقدي)
- **تقارير مالية شاملة** مع رسوم بيانية تفاعلية

### 📄 طباعة احترافية
- **فواتير PDF احترافية** بتصميم يشبه InvoiceHome
- **دعم كامل للعربية في PDF**
- **معلومات الشركة والعميل**
- **تفاصيل الدفع والحسابات البنكية**

### 🎨 تصميم متطور
- **واجهة تشبه macOS** أنيقة ومتطورة
- **تصميم متجاوب** لجميع الأجهزة
- **ألوان متناسقة** ومريحة للعين
- **تجربة مستخدم سلسة**

## 🚀 البدء السريع

### المتطلبات
- Node.js 18+ 
- pnpm أو npm أو yarn

### التثبيت

```bash
# استنساخ المشروع
git clone https://github.com/yourusername/kayan-financial-app.git
cd kayan-financial-app

# تثبيت التبعيات
pnpm install
# أو
npm install

# تشغيل خادم التطوير
pnpm dev
# أو
npm run dev
```

### البناء للإنتاج

```bash
# بناء التطبيق
pnpm build
# أو
npm run build

# معاينة البناء
pnpm preview
# أو
npm run preview
```

## 📱 الصفحات والوظائف

### 🏠 الصفحة الرئيسية (Dashboard)
- إحصائيات شاملة للأعمال
- رسوم بيانية للإيرادات والأرباح الشهرية
- التنقل السريع للوظائف الأساسية
- عرض الفواتير الأخيرة

### 📋 إدارة الفواتير
- إنشاء فواتير جديدة مع اختيار المنتجات
- حساب الأرباح التلقائي لكل بند
- دعم الدفع الجزئي مع تتبع المتبقي
- ربط بطرق الدفع والحسابات البنكية
- طباعة الفواتير كـ PDF احترافي
- فلترة وبحث متقدم

### 👥 إدارة العملاء
- قاعدة بيانات شاملة للعملاء
- تحليلات مفصلة لكل عميل:
  - إجمالي الفواتير والمبيعات
  - إجمالي الأرباح من العميل
  - رسوم بيانية شهرية
- تحميل فواتير العميل مجمعة

### 📦 إدارة المنتجات
- كتالوج المنتجات مع الأسعار والتكاليف
- حساب هامش الربح لكل منتج
- أسماء المنتجات بالعربية والإنجليزية
- اختيار تلقائي عند إنشاء الفواتير

### 🏢 إدارة الموردين
- قاعدة بيانات الموردين
- معلومات الاتصال والعناوين
- تصنيف الموردين حسب النوع
- منفصلة عن حسابات الأرباح

### 💸 إدارة المصروفات
- تسجيل المصروفات مع التصنيف:
  - مصروفاتي الشخصية
  - مصروفات زوجتي (دعاء)
- فلترة المصروفات حسب النوع والشهر
- تحليل توزيع المصروفات

### 📊 التقارير والتحليلات
- تقارير الإيرادات والأرباح الشهرية
- تحليل الأرباح حسب العملاء والمنتجات
- رسوم بيانية تفاعلية (خطية، عمودية، دائرية)
- مقارنات شهرية وإحصائيات متقدمة
- تقارير المصروفات مع التصنيف

## 🏦 الحسابات البنكية المدعومة

- **KHARTOUM_PERSONAL**: حساب شخصي - بنك الخرطوم
- **OMDURMAN_PERSONAL**: حساب شخصي - بنك أمدرمان  
- **OMDURMAN_COMPANY**: حساب الشركة - بنك أمدرمان
- **CASH**: الدفع النقدي

## 🛠️ التقنيات المستخدمة

### Frontend
- **React 18** - مكتبة واجهة المستخدم
- **Vite** - أداة البناء السريعة
- **Tailwind CSS** - إطار عمل CSS
- **shadcn/ui** - مكونات UI جاهزة

### المكتبات الإضافية
- **Recharts** - الرسوم البيانية التفاعلية
- **Lucide React** - الأيقونات
- **jsPDF** - توليد ملفات PDF
- **React Context** - إدارة الحالة

### التخزين
- **Local Storage** - تخزين البيانات محلياً
- **JSON** - تنسيق البيانات

## 📁 هيكل المشروع

```
kayan-financial-app/
├── public/                 # الملفات العامة
├── src/
│   ├── components/         # مكونات React
│   │   ├── Dashboard.jsx   # لوحة التحكم
│   │   ├── Invoices.jsx    # إدارة الفواتير
│   │   ├── CreateInvoice.jsx # إنشاء فاتورة
│   │   ├── Customers.jsx   # إدارة العملاء
│   │   ├── Products.jsx    # إدارة المنتجات
│   │   ├── Suppliers.jsx   # إدارة الموردين
│   │   ├── Expenses.jsx    # إدارة المصروفات
│   │   ├── Reports.jsx     # التقارير
│   │   └── Sidebar.jsx     # الشريط الجانبي
│   ├── contexts/           # React Contexts
│   │   └── LanguageContext.jsx # إدارة اللغة
│   ├── utils/              # الأدوات المساعدة
│   │   ├── dataStore.js    # إدارة البيانات
│   │   ├── translations.js # الترجمات
│   │   ├── pdfGenerator.js # توليد PDF
│   │   └── clearData.js    # مسح البيانات
│   ├── App.jsx             # المكون الرئيسي
│   ├── main.jsx            # نقطة الدخول
│   └── index.css           # الأنماط الرئيسية
├── package.json            # تبعيات المشروع
├── vite.config.js          # إعدادات Vite
├── tailwind.config.js      # إعدادات Tailwind
└── README.md               # هذا الملف
```

## 🔧 التخصيص والتطوير

### إضافة لغة جديدة
1. أضف الترجمات في `src/utils/translations.js`
2. حدث `LanguageContext.jsx` لدعم اللغة الجديدة
3. أضف دعم RTL إذا لزم الأمر في CSS

### إضافة حساب بنكي جديد
1. أضف الحساب في `src/utils/dataStore.js`
2. حدث الترجمات في `translations.js`
3. أضف الحساب في مكون إنشاء الفاتورة

### تخصيص تصميم PDF
1. عدل `src/utils/pdfGenerator.js`
2. غير الألوان والخطوط والتخطيط
3. أضف شعار الشركة إذا لزم الأمر

## 📊 البيانات والتخزين

### تنسيق البيانات
جميع البيانات تُخزن في Local Storage بتنسيق JSON:

```javascript
// الفواتير
{
  id: number,
  invoiceNumber: string,
  customerId: number,
  customerName: string,
  items: Array,
  subtotal: number,
  tax: number,
  total: number,
  totalProfit: number,
  paymentMethod: string,
  paymentStatus: 'paid' | 'partial' | 'unpaid',
  paidAmount: number,
  remainingAmount: number,
  createdAt: string,
  dueDate: string
}

// العملاء
{
  id: number,
  name: string,
  nameEn: string,
  email: string,
  phone: string,
  address: string,
  addressEn: string,
  createdAt: string
}

// المنتجات
{
  id: number,
  name: string,
  nameEn: string,
  price: number,
  cost: number,
  category: string,
  createdAt: string
}
```

### مسح البيانات
لمسح جميع البيانات واستعادة التطبيق لحالته الأولى:

```javascript
import { resetToCleanState } from './src/utils/clearData.js';
resetToCleanState();
```

## 🚀 النشر

### Vercel
```bash
# تثبيت Vercel CLI
npm i -g vercel

# نشر التطبيق
vercel
```

### Netlify
```bash
# بناء التطبيق
npm run build

# رفع مجلد dist إلى Netlify
```

### GitHub Pages
```bash
# تثبيت gh-pages
npm install --save-dev gh-pages

# إضافة سكريبت النشر في package.json
"deploy": "gh-pages -d dist"

# النشر
npm run build && npm run deploy
```

## 🤝 المساهمة

نرحب بالمساهمات! يرجى اتباع الخطوات التالية:

1. Fork المشروع
2. إنشاء فرع للميزة الجديدة (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push للفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

## 📝 الترخيص

هذا المشروع مرخص تحت رخصة MIT - راجع ملف [LICENSE](LICENSE) للتفاصيل.

## 📞 التواصل

- **المطور**: [اسمك]
- **البريد الإلكتروني**: [بريدك الإلكتروني]
- **GitHub**: [رابط GitHub الخاص بك]

## 🙏 شكر وتقدير

- **React Team** - لمكتبة React الرائعة
- **Tailwind CSS** - لإطار العمل المتميز
- **Recharts** - للرسوم البيانية التفاعلية
- **shadcn/ui** - للمكونات الجاهزة

---

**تم تطوير هذا التطبيق بـ ❤️ للمجتمع العربي**

