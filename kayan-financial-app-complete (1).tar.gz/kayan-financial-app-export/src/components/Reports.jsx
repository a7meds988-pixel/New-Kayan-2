import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  BarChart3, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Package,
  Download,
  Calendar,
  Filter
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from 'recharts';

const Reports = () => {
  const { language, formatCurrency, formatNumber, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [analytics, setAnalytics] = useState({});
  const [monthlyData, setMonthlyData] = useState([]);
  const [customerData, setCustomerData] = useState([]);
  const [productData, setProductData] = useState([]);
  const [expenseData, setExpenseData] = useState([]);
  const [selectedPeriod, setSelectedPeriod] = useState('6months');

  useEffect(() => {
    loadReportsData();
  }, [selectedPeriod]);

  const loadReportsData = () => {
    // Load analytics
    const analyticsData = dataStore.getAnalytics();
    setAnalytics(analyticsData);

    // Load monthly data
    const monthly = dataStore.getMonthlyData();
    const chartData = Object.entries(monthly).map(([month, data]) => ({
      month: new Date(month + '-01').toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', { month: 'short', year: '2-digit' }),
      revenue: data.revenue,
      profit: data.profit,
      expenses: data.expenses,
      netProfit: data.profit - data.expenses
    }));

    // Filter based on selected period
    const periodMonths = selectedPeriod === '3months' ? 3 : selectedPeriod === '6months' ? 6 : 12;
    setMonthlyData(chartData.slice(-periodMonths));

    // Load customer analytics
    const customers = dataStore.getCustomers();
    const customerAnalytics = customers.map(customer => {
      const analytics = dataStore.getCustomerAnalytics(customer.id);
      return {
        name: language === 'ar' ? customer.name : (customer.nameEn || customer.name),
        sales: analytics.totalAmount,
        profit: analytics.totalProfit,
        invoices: analytics.totalInvoices
      };
    }).filter(c => c.sales > 0).sort((a, b) => b.sales - a.sales).slice(0, 10);
    setCustomerData(customerAnalytics);

    // Load product analytics
    const products = dataStore.getProducts();
    const invoices = dataStore.getInvoices();
    const productAnalytics = products.map(product => {
      let totalSold = 0;
      let totalRevenue = 0;
      let totalProfit = 0;

      invoices.forEach(invoice => {
        invoice.items.forEach(item => {
          if (item.productId === product.id) {
            totalSold += item.quantity;
            totalRevenue += item.total;
            totalProfit += item.profit;
          }
        });
      });

      return {
        name: language === 'ar' ? product.name : (product.nameEn || product.name),
        sold: totalSold,
        revenue: totalRevenue,
        profit: totalProfit
      };
    }).filter(p => p.sold > 0).sort((a, b) => b.revenue - a.revenue).slice(0, 10);
    setProductData(productAnalytics);

    // Load expense data by type
    const expenses = dataStore.getExpenses();
    const expenseByType = {};
    expenses.forEach(expense => {
      const type = expense.type === 'personal' ? 
        (language === 'ar' ? 'مصروفاتي الشخصية' : 'Personal Expenses') :
        (language === 'ar' ? 'مصروفات زوجتي (دعاء)' : 'Wife Expenses (Duaa)');
      
      if (!expenseByType[type]) {
        expenseByType[type] = 0;
      }
      expenseByType[type] += expense.amount;
    });

    const expenseChartData = Object.entries(expenseByType).map(([type, amount]) => ({
      type,
      amount,
      percentage: ((amount / Object.values(expenseByType).reduce((a, b) => a + b, 0)) * 100).toFixed(1)
    }));
    setExpenseData(expenseChartData);
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

  const periodOptions = [
    { value: '3months', label: language === 'ar' ? '3 أشهر' : '3 Months' },
    { value: '6months', label: language === 'ar' ? '6 أشهر' : '6 Months' },
    { value: '12months', label: language === 'ar' ? '12 شهر' : '12 Months' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('reports')}</h1>
        <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {periodOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download size={16} className={isRTL ? 'ml-2' : 'mr-2'} />
            {t('export')}
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('totalRevenue')}</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(analytics.totalRevenue || 0)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'إجمالي المبيعات' : 'total sales'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('totalProfit')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(analytics.totalProfit || 0)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'إجمالي الأرباح' : 'gross profit'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('netProfits')}</CardTitle>
            <BarChart3 className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{formatCurrency(analytics.netProfit || 0)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'بعد خصم المصروفات' : 'after expenses'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'هامش الربح' : 'Profit Margin'}
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {analytics.totalRevenue > 0 ? ((analytics.totalProfit / analytics.totalRevenue) * 100).toFixed(1) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'نسبة الربح للمبيعات' : 'profit to sales ratio'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Revenue & Profit Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'اتجاهات الإيرادات والأرباح' : 'Revenue & Profit Trends'}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => formatCurrency(value)}
                  labelStyle={{ direction: isRTL ? 'rtl' : 'ltr' }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  name={t('revenue')}
                />
                <Line 
                  type="monotone" 
                  dataKey="profit" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name={t('profit')}
                />
                <Line 
                  type="monotone" 
                  dataKey="netProfit" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  name={t('netProfits')}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'الإيرادات مقابل المصروفات' : 'Revenue vs Expenses'}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => formatCurrency(value)}
                  labelStyle={{ direction: isRTL ? 'rtl' : 'ltr' }}
                />
                <Legend />
                <Bar dataKey="revenue" fill="#10b981" name={t('revenue')} />
                <Bar dataKey="expenses" fill="#ef4444" name={t('expenses')} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top Customers & Products */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{t('profitsByCustomer')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {customerData.slice(0, 5).map((customer, index) => (
                <div key={index} className={`flex items-center justify-between p-3 rounded-lg bg-muted/50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium text-primary`}>
                      {index + 1}
                    </div>
                    <div className={isRTL ? 'text-right' : 'text-left'}>
                      <p className="font-medium text-sm">{customer.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {customer.invoices} {language === 'ar' ? 'فاتورة' : 'invoices'}
                      </p>
                    </div>
                  </div>
                  <div className={`text-right ${isRTL ? 'text-left' : ''}`}>
                    <p className="font-semibold text-sm text-green-600">{formatCurrency(customer.sales)}</p>
                    <p className="text-xs text-blue-600">{formatCurrency(customer.profit)} {language === 'ar' ? 'ربح' : 'profit'}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{t('profitsByProduct')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {productData.slice(0, 5).map((product, index) => (
                <div key={index} className={`flex items-center justify-between p-3 rounded-lg bg-muted/50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-sm font-medium text-green-600`}>
                      {index + 1}
                    </div>
                    <div className={isRTL ? 'text-right' : 'text-left'}>
                      <p className="font-medium text-sm">{product.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {product.sold} {language === 'ar' ? 'وحدة مباعة' : 'units sold'}
                      </p>
                    </div>
                  </div>
                  <div className={`text-right ${isRTL ? 'text-left' : ''}`}>
                    <p className="font-semibold text-sm text-green-600">{formatCurrency(product.revenue)}</p>
                    <p className="text-xs text-blue-600">{formatCurrency(product.profit)} {language === 'ar' ? 'ربح' : 'profit'}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Expense Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'توزيع المصروفات' : 'Expense Distribution'}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={expenseData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ type, percentage }) => `${type}: ${percentage}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="amount"
                >
                  {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'ملخص المصروفات' : 'Expense Summary'}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {expenseData.map((expense, index) => (
                <div key={index} className={`flex items-center justify-between p-3 rounded-lg bg-muted/50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <div 
                      className="w-4 h-4 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    ></div>
                    <span className="font-medium text-sm">{expense.type}</span>
                  </div>
                  <div className={`text-right ${isRTL ? 'text-left' : ''}`}>
                    <p className="font-semibold text-sm text-red-600">{formatCurrency(expense.amount)}</p>
                    <p className="text-xs text-muted-foreground">{expense.percentage}%</p>
                  </div>
                </div>
              ))}
              
              <div className={`flex items-center justify-between p-3 rounded-lg bg-primary/10 border-t ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span className="font-semibold">{language === 'ar' ? 'إجمالي المصروفات' : 'Total Expenses'}:</span>
                <span className="font-bold text-red-600">
                  {formatCurrency(expenseData.reduce((sum, exp) => sum + exp.amount, 0))}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Comparison */}
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>{t('monthlyComparison')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>{language === 'ar' ? 'الشهر' : 'Month'}</th>
                  <th>{t('revenue')}</th>
                  <th>{t('expenses')}</th>
                  <th>{language === 'ar' ? 'الربح الإجمالي' : 'Gross Profit'}</th>
                  <th>{t('netProfits')}</th>
                  <th>{language === 'ar' ? 'هامش الربح' : 'Profit Margin'}</th>
                </tr>
              </thead>
              <tbody>
                {monthlyData.map((month, index) => {
                  const profitMargin = month.revenue > 0 ? ((month.netProfit / month.revenue) * 100).toFixed(1) : 0;
                  return (
                    <tr key={index}>
                      <td className="font-medium">{month.month}</td>
                      <td className="font-semibold text-green-600">{formatCurrency(month.revenue)}</td>
                      <td className="font-semibold text-red-600">{formatCurrency(month.expenses)}</td>
                      <td className="font-semibold text-blue-600">{formatCurrency(month.profit)}</td>
                      <td className="font-semibold text-purple-600">{formatCurrency(month.netProfit)}</td>
                      <td className={`font-semibold ${profitMargin >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {profitMargin}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;

