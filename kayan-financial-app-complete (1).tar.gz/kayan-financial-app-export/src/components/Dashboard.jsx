import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  DollarSign, 
  FileText, 
  TrendingUp, 
  Users, 
  Package,
  CreditCard,
  BarChart3,
  ArrowUpRight,
  ArrowDownRight,
  Plus
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

const Dashboard = () => {
  const { language, formatCurrency, formatNumber, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [analytics, setAnalytics] = useState({});
  const [monthlyData, setMonthlyData] = useState([]);
  const [recentInvoices, setRecentInvoices] = useState([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = () => {
    const analyticsData = dataStore.getAnalytics();
    const monthly = dataStore.getMonthlyData();
    const invoices = dataStore.getInvoices().slice(-5).reverse(); // Last 5 invoices

    setAnalytics(analyticsData);
    setRecentInvoices(invoices);

    // Convert monthly data to chart format
    const chartData = Object.entries(monthly).map(([month, data]) => ({
      month: new Date(month + '-01').toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', { month: 'short' }),
      revenue: data.revenue,
      profit: data.profit,
      expenses: data.expenses
    })).slice(-6); // Last 6 months

    setMonthlyData(chartData);
  };

  const quickActions = [
    {
      title: t('createInvoice'),
      description: language === 'ar' ? 'إنشاء فاتورة جديدة للعميل' : 'Create a new invoice for customer',
      link: '/create-invoice',
      icon: FileText,
      color: 'bg-blue-500'
    },
    {
      title: t('addProduct'),
      description: language === 'ar' ? 'إضافة منتج جديد للمخزون' : 'Add new product to inventory',
      link: '/products',
      icon: Package,
      color: 'bg-green-500'
    },
    {
      title: t('customers'),
      description: language === 'ar' ? 'إدارة قاعدة بيانات العملاء' : 'Manage customer database',
      link: '/customers',
      icon: Users,
      color: 'bg-purple-500'
    },
    {
      title: t('reports'),
      description: language === 'ar' ? 'عرض التقارير والتحليلات' : 'View reports and analytics',
      link: '/reports',
      icon: BarChart3,
      color: 'bg-orange-500'
    }
  ];

  const statCards = [
    {
      title: t('totalRevenue'),
      value: formatCurrency(analytics.totalRevenue || 0),
      change: '+12.5%',
      changeType: 'positive',
      icon: DollarSign,
      color: 'text-green-600'
    },
    {
      title: t('totalProfit'),
      value: formatCurrency(analytics.totalProfit || 0),
      change: '+8.2%',
      changeType: 'positive',
      icon: TrendingUp,
      color: 'text-blue-600'
    },
    {
      title: t('totalInvoices'),
      value: formatNumber(analytics.totalInvoices || 0),
      change: '+15.3%',
      changeType: 'positive',
      icon: FileText,
      color: 'text-purple-600'
    },
    {
      title: t('totalCustomers'),
      value: formatNumber(analytics.totalCustomers || 0),
      change: '+5.1%',
      changeType: 'positive',
      icon: Users,
      color: 'text-orange-600'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <div>
          <h1 className="text-3xl font-bold">{t('dashboard')}</h1>
          <p className="text-muted-foreground mt-1">
            {language === 'ar' ? 'نظرة عامة على أداء أعمالك' : 'Overview of your business performance'}
          </p>
        </div>
        <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Link to="/create-invoice">
            <Button className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Plus size={20} />
              {t('createInvoice')}
            </Button>
          </Link>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="stat-card">
              <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                <div className={`flex items-center text-xs ${isRTL ? 'flex-row-reverse' : ''}`}>
                  {stat.changeType === 'positive' ? (
                    <ArrowUpRight className="h-3 w-3 text-green-500" />
                  ) : (
                    <ArrowDownRight className="h-3 w-3 text-red-500" />
                  )}
                  <span className={`${stat.changeType === 'positive' ? 'text-green-500' : 'text-red-500'} ${isRTL ? 'mr-1' : 'ml-1'}`}>
                    {stat.change}
                  </span>
                  <span className="text-muted-foreground">
                    {language === 'ar' ? 'من الشهر الماضي' : 'from last month'}
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Chart */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'الإيرادات والأرباح الشهرية' : 'Monthly Revenue & Profit'}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => formatCurrency(value)}
                  labelStyle={{ direction: isRTL ? 'rtl' : 'ltr' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  name={t('revenue')}
                />
                <Line 
                  type="monotone" 
                  dataKey="profit" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name={t('profit')}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Expenses Chart */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{language === 'ar' ? 'المصروفات الشهرية' : 'Monthly Expenses'}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip 
                  formatter={(value) => formatCurrency(value)}
                  labelStyle={{ direction: isRTL ? 'rtl' : 'ltr' }}
                />
                <Bar dataKey="expenses" fill="#ef4444" name={t('expenses')} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions & Recent Invoices */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Quick Actions */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle>{t('quickNavigation')}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {quickActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Link key={index} to={action.link}>
                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardContent className="p-4">
                        <div className={`flex items-center gap-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <div className={`p-2 rounded-md ${action.color} text-white`}>
                            <Icon size={20} />
                          </div>
                          <div className={isRTL ? 'text-right' : 'text-left'}>
                            <h3 className="font-semibold text-sm">{action.title}</h3>
                            <p className="text-xs text-muted-foreground">{action.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Recent Invoices */}
        <Card className="financial-card">
          <CardHeader className={`flex flex-row items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle>{language === 'ar' ? 'الفواتير الأخيرة' : 'Recent Invoices'}</CardTitle>
            <Link to="/invoices">
              <Button variant="outline" size="sm">
                {language === 'ar' ? 'عرض الكل' : 'View All'}
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentInvoices.map((invoice) => (
                <div key={invoice.id} className={`flex items-center justify-between p-3 rounded-md bg-muted/50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <div className={isRTL ? 'text-right' : 'text-left'}>
                    <p className="font-medium text-sm">{invoice.invoiceNumber}</p>
                    <p className="text-xs text-muted-foreground">{invoice.customerName}</p>
                  </div>
                  <div className={`text-right ${isRTL ? 'text-left' : ''}`}>
                    <p className="font-semibold text-sm">{formatCurrency(invoice.total)}</p>
                    <p className={`text-xs ${
                      invoice.paymentStatus === 'paid' ? 'text-green-600' : 
                      invoice.paymentStatus === 'partial' ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {t(invoice.paymentStatus)}
                    </p>
                  </div>
                </div>
              ))}
              
              {recentInvoices.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  {language === 'ar' ? 'لا توجد فواتير حديثة' : 'No recent invoices'}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;

