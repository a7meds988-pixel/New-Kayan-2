import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Search, 
  Filter, 
  Edit, 
  Trash2,
  CreditCard,
  DollarSign,
  Calendar,
  User,
  Heart
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const Expenses = () => {
  const { language, formatCurrency, formatDate, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [expenses, setExpenses] = useState([]);
  const [filteredExpenses, setFilteredExpenses] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [monthFilter, setMonthFilter] = useState('all');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [formData, setFormData] = useState({
    description: '',
    descriptionEn: '',
    amount: '',
    type: 'personal',
    category: '',
    date: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    loadExpenses();
  }, []);

  useEffect(() => {
    filterExpenses();
  }, [expenses, searchTerm, typeFilter, monthFilter]);

  const loadExpenses = () => {
    const expensesData = dataStore.getExpenses().sort((a, b) => new Date(b.date) - new Date(a.date));
    setExpenses(expensesData);
  };

  const filterExpenses = () => {
    let filtered = expenses;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(expense => {
        const description = language === 'ar' ? expense.description : (expense.descriptionEn || expense.description);
        return description.toLowerCase().includes(searchTerm.toLowerCase()) ||
               expense.category?.toLowerCase().includes(searchTerm.toLowerCase());
      });
    }

    // Type filter
    if (typeFilter !== 'all') {
      filtered = filtered.filter(expense => expense.type === typeFilter);
    }

    // Month filter
    if (monthFilter !== 'all') {
      filtered = filtered.filter(expense => {
        const expenseMonth = new Date(expense.date).toISOString().slice(0, 7);
        return expenseMonth === monthFilter;
      });
    }

    setFilteredExpenses(filtered);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const expenseData = {
      description: formData.description,
      descriptionEn: formData.descriptionEn,
      amount: parseFloat(formData.amount),
      type: formData.type,
      category: formData.category,
      date: formData.date
    };

    if (editingExpense) {
      dataStore.updateExpense(editingExpense.id, expenseData);
    } else {
      dataStore.addExpense(expenseData);
    }

    loadExpenses();
    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      description: '',
      descriptionEn: '',
      amount: '',
      type: 'personal',
      category: '',
      date: new Date().toISOString().split('T')[0]
    });
    setEditingExpense(null);
  };

  const handleEdit = (expense) => {
    setEditingExpense(expense);
    setFormData({
      description: expense.description,
      descriptionEn: expense.descriptionEn || '',
      amount: expense.amount.toString(),
      type: expense.type,
      category: expense.category || '',
      date: expense.date.split('T')[0]
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    if (window.confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا المصروف؟' : 'Are you sure you want to delete this expense?')) {
      dataStore.deleteExpense(id);
      loadExpenses();
    }
  };

  // Calculate summary statistics
  const totalExpenses = filteredExpenses.reduce((sum, exp) => sum + exp.amount, 0);
  const personalExpenses = filteredExpenses.filter(exp => exp.type === 'personal').reduce((sum, exp) => sum + exp.amount, 0);
  const wifeExpenses = filteredExpenses.filter(exp => exp.type === 'wife').reduce((sum, exp) => sum + exp.amount, 0);
  const currentMonthExpenses = filteredExpenses.filter(exp => {
    const expenseMonth = new Date(exp.date).toISOString().slice(0, 7);
    const currentMonth = new Date().toISOString().slice(0, 7);
    return expenseMonth === currentMonth;
  }).reduce((sum, exp) => sum + exp.amount, 0);

  // Get unique months for filter
  const availableMonths = [...new Set(expenses.map(exp => new Date(exp.date).toISOString().slice(0, 7)))].sort().reverse();

  const typeOptions = [
    { value: 'all', label: language === 'ar' ? 'جميع الأنواع' : 'All Types' },
    { value: 'personal', label: t('personalExpenses') },
    { value: 'wife', label: t('wifeExpenses') }
  ];

  const monthOptions = [
    { value: 'all', label: language === 'ar' ? 'جميع الأشهر' : 'All Months' },
    ...availableMonths.map(month => ({
      value: month,
      label: new Date(month + '-01').toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', { month: 'long', year: 'numeric' })
    }))
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('expenses')}</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`} onClick={resetForm}>
              <Plus size={20} />
              {language === 'ar' ? 'إضافة مصروف' : 'Add Expense'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingExpense ? 
                  (language === 'ar' ? 'تعديل المصروف' : 'Edit Expense') : 
                  (language === 'ar' ? 'إضافة مصروف جديد' : 'Add New Expense')
                }
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>{language === 'ar' ? 'الوصف (عربي)' : 'Description (Arabic)'}</Label>
                <Input
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  required
                  dir="rtl"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'الوصف (إنجليزي)' : 'Description (English)'}</Label>
                <Input
                  value={formData.descriptionEn}
                  onChange={(e) => setFormData({...formData, descriptionEn: e.target.value})}
                  dir="ltr"
                />
              </div>
              <div>
                <Label>{t('amount')}</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({...formData, amount: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label>{t('type')}</Label>
                <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">{t('personalExpenses')}</SelectItem>
                    <SelectItem value="wife">{t('wifeExpenses')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>{language === 'ar' ? 'الفئة' : 'Category'}</Label>
                <Input
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  placeholder={language === 'ar' ? 'مثل: طعام، مواصلات، إيجار' : 'e.g: Food, Transport, Rent'}
                />
              </div>
              <div>
                <Label>{t('date')}</Label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                  required
                />
              </div>
              <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Button type="submit" className="flex-1">{t('save')}</Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                  {t('cancel')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي المصروفات' : 'Total Expenses'}
            </CardTitle>
            <CreditCard className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalExpenses)}</div>
            <p className="text-xs text-muted-foreground">
              {filteredExpenses.length} {language === 'ar' ? 'مصروف' : 'expenses'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('personalExpenses')}</CardTitle>
            <User className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(personalExpenses)}</div>
            <p className="text-xs text-muted-foreground">
              {totalExpenses > 0 ? ((personalExpenses / totalExpenses) * 100).toFixed(1) : 0}% {language === 'ar' ? 'من الإجمالي' : 'of total'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('wifeExpenses')}</CardTitle>
            <Heart className="h-4 w-4 text-pink-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pink-600">{formatCurrency(wifeExpenses)}</div>
            <p className="text-xs text-muted-foreground">
              {totalExpenses > 0 ? ((wifeExpenses / totalExpenses) * 100).toFixed(1) : 0}% {language === 'ar' ? 'من الإجمالي' : 'of total'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'مصروفات هذا الشهر' : 'This Month'}
            </CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{formatCurrency(currentMonthExpenses)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'الشهر الحالي' : 'current month'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="financial-card">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>{t('search')}</Label>
              <div className="relative">
                <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-muted-foreground`} size={20} />
                <Input
                  placeholder={language === 'ar' ? 'البحث في المصروفات...' : 'Search expenses...'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`${isRTL ? 'pr-10' : 'pl-10'}`}
                />
              </div>
            </div>
            
            <div>
              <Label>{t('filterByType')}</Label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {typeOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>{t('filterByMonth')}</Label>
              <Select value={monthFilter} onValueChange={setMonthFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button variant="outline" className="w-full">
                <Filter size={16} className={isRTL ? 'ml-2' : 'mr-2'} />
                {language === 'ar' ? 'تصفية متقدمة' : 'Advanced Filter'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Expenses Table */}
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>{language === 'ar' ? 'قائمة المصروفات' : 'Expenses List'}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>{t('description')}</th>
                  <th>{t('amount')}</th>
                  <th>{t('type')}</th>
                  <th>{language === 'ar' ? 'الفئة' : 'Category'}</th>
                  <th>{t('date')}</th>
                  <th>{t('actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredExpenses.map((expense) => {
                  const displayDescription = language === 'ar' ? expense.description : (expense.descriptionEn || expense.description);
                  const typeIcon = expense.type === 'personal' ? <User size={16} className="text-blue-600" /> : <Heart size={16} className="text-pink-600" />;
                  
                  return (
                    <tr key={expense.id}>
                      <td className="font-medium">{displayDescription}</td>
                      <td className="font-semibold text-red-600">{formatCurrency(expense.amount)}</td>
                      <td>
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          {typeIcon}
                          <span className="text-sm">
                            {expense.type === 'personal' ? t('personalExpenses') : t('wifeExpenses')}
                          </span>
                        </div>
                      </td>
                      <td>
                        <span className="text-sm bg-muted px-2 py-1 rounded">
                          {expense.category || '-'}
                        </span>
                      </td>
                      <td className="text-sm text-muted-foreground">{formatDate(expense.date)}</td>
                      <td>
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleEdit(expense)}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-destructive"
                            onClick={() => handleDelete(expense.id)}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredExpenses.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {language === 'ar' ? 'لا توجد مصروفات' : 'No expenses found'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Expenses;

