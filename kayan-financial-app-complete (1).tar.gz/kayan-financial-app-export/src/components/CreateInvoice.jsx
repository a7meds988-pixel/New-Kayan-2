import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { 
  Plus, 
  Trash2, 
  Save, 
  Calculator,
  User,
  Package,
  CreditCard
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const CreateInvoice = () => {
  const navigate = useNavigate();
  const { language, formatCurrency, isRTL } = useLanguage();
  const t = useTranslation(language);
  
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    nameEn: '',
    email: '',
    phone: '',
    address: '',
    addressEn: ''
  });
  const [isNewCustomerDialogOpen, setIsNewCustomerDialogOpen] = useState(false);
  
  const [invoiceItems, setInvoiceItems] = useState([]);
  const [paymentMethod, setPaymentMethod] = useState('');
  const [paymentStatus, setPaymentStatus] = useState('unpaid');
  const [paidAmount, setPaidAmount] = useState('');
  const [notes, setNotes] = useState('');

  const paymentMethods = [
    { value: 'KHARTOUM_PERSONAL', label: t('KHARTOUM_PERSONAL') },
    { value: 'OMDURMAN_PERSONAL', label: t('OMDURMAN_PERSONAL') },
    { value: 'OMDURMAN_COMPANY', label: t('OMDURMAN_COMPANY') },
    { value: 'cash', label: t('cash') }
  ];

  useEffect(() => {
    setCustomers(dataStore.getCustomers());
    setProducts(dataStore.getProducts());
  }, []);

  const addInvoiceItem = () => {
    setInvoiceItems([...invoiceItems, {
      id: Date.now(),
      productId: '',
      name: '',
      nameEn: '',
      quantity: 1,
      price: 0,
      cost: 0,
      total: 0,
      profit: 0
    }]);
  };

  const updateInvoiceItem = (id, field, value) => {
    setInvoiceItems(items => items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        // Auto-calculate when quantity or price changes
        if (field === 'quantity' || field === 'price') {
          updatedItem.total = updatedItem.quantity * updatedItem.price;
          updatedItem.profit = (updatedItem.price - updatedItem.cost) * updatedItem.quantity;
        }
        
        return updatedItem;
      }
      return item;
    }));
  };

  const selectProduct = (itemId, productId) => {
    const product = products.find(p => p.id === parseInt(productId));
    if (product) {
      updateInvoiceItem(itemId, 'productId', productId);
      updateInvoiceItem(itemId, 'name', product.name);
      updateInvoiceItem(itemId, 'nameEn', product.nameEn || '');
      updateInvoiceItem(itemId, 'price', product.price);
      updateInvoiceItem(itemId, 'cost', product.cost);
      updateInvoiceItem(itemId, 'total', product.price);
      updateInvoiceItem(itemId, 'profit', product.price - product.cost);
    }
  };

  const removeInvoiceItem = (id) => {
    setInvoiceItems(items => items.filter(item => item.id !== id));
  };

  const calculateTotals = () => {
    const subtotal = invoiceItems.reduce((sum, item) => sum + item.total, 0);
    const totalProfit = invoiceItems.reduce((sum, item) => sum + item.profit, 0);
    const tax = 0; // Can be configured later
    const total = subtotal + tax;
    
    return { subtotal, totalProfit, tax, total };
  };

  const handleAddCustomer = (e) => {
    e.preventDefault();
    const customer = dataStore.addCustomer(newCustomer);
    setCustomers([...customers, customer]);
    setSelectedCustomer(customer.id.toString());
    setNewCustomer({
      name: '',
      nameEn: '',
      email: '',
      phone: '',
      address: '',
      addressEn: ''
    });
    setIsNewCustomerDialogOpen(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!selectedCustomer || invoiceItems.length === 0) {
      alert(language === 'ar' ? 'يرجى اختيار عميل وإضافة منتجات' : 'Please select a customer and add products');
      return;
    }

    const customer = customers.find(c => c.id === parseInt(selectedCustomer));
    const totals = calculateTotals();
    const paidAmountNum = parseFloat(paidAmount) || 0;
    
    const invoice = {
      customerId: parseInt(selectedCustomer),
      customerName: language === 'ar' ? customer.name : (customer.nameEn || customer.name),
      items: invoiceItems,
      subtotal: totals.subtotal,
      tax: totals.tax,
      total: totals.total,
      totalProfit: totals.totalProfit,
      paymentMethod,
      paymentStatus: paidAmountNum >= totals.total ? 'paid' : paidAmountNum > 0 ? 'partial' : 'unpaid',
      paidAmount: paidAmountNum,
      remainingAmount: totals.total - paidAmountNum,
      notes,
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days from now
    };

    dataStore.addInvoice(invoice);
    navigate('/invoices');
  };

  const totals = calculateTotals();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('createInvoice')}</h1>
        <Button variant="outline" onClick={() => navigate('/invoices')}>
          {language === 'ar' ? 'العودة للفواتير' : 'Back to Invoices'}
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Customer Selection */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <User size={20} />
              {language === 'ar' ? 'معلومات العميل' : 'Customer Information'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className="flex-1">
                <Label htmlFor="customer">{t('customerName')}</Label>
                <Select value={selectedCustomer} onValueChange={setSelectedCustomer}>
                  <SelectTrigger>
                    <SelectValue placeholder={language === 'ar' ? 'اختر عميل' : 'Select customer'} />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map(customer => (
                      <SelectItem key={customer.id} value={customer.id.toString()}>
                        {language === 'ar' ? customer.name : (customer.nameEn || customer.name)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Dialog open={isNewCustomerDialogOpen} onOpenChange={setIsNewCustomerDialogOpen}>
                  <DialogTrigger asChild>
                    <Button type="button" variant="outline">
                      <Plus size={16} className={isRTL ? 'ml-2' : 'mr-2'} />
                      {language === 'ar' ? 'عميل جديد' : 'New Customer'}
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-md">
                    <DialogHeader>
                      <DialogTitle>{language === 'ar' ? 'إضافة عميل جديد' : 'Add New Customer'}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleAddCustomer} className="space-y-4">
                      <div>
                        <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                        <Input
                          value={newCustomer.name}
                          onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                          required
                          dir="rtl"
                        />
                      </div>
                      <div>
                        <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                        <Input
                          value={newCustomer.nameEn}
                          onChange={(e) => setNewCustomer({...newCustomer, nameEn: e.target.value})}
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <Label>{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</Label>
                        <Input
                          type="email"
                          value={newCustomer.email}
                          onChange={(e) => setNewCustomer({...newCustomer, email: e.target.value})}
                        />
                      </div>
                      <div>
                        <Label>{language === 'ar' ? 'رقم الهاتف' : 'Phone'}</Label>
                        <Input
                          value={newCustomer.phone}
                          onChange={(e) => setNewCustomer({...newCustomer, phone: e.target.value})}
                        />
                      </div>
                      <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Button type="submit" className="flex-1">{t('save')}</Button>
                        <Button type="button" variant="outline" onClick={() => setIsNewCustomerDialogOpen(false)} className="flex-1">
                          {t('cancel')}
                        </Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Invoice Items */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
              <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Package size={20} />
                {language === 'ar' ? 'بنود الفاتورة' : 'Invoice Items'}
              </div>
              <Button type="button" onClick={addInvoiceItem} size="sm">
                <Plus size={16} className={isRTL ? 'ml-2' : 'mr-2'} />
                {language === 'ar' ? 'إضافة بند' : 'Add Item'}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {invoiceItems.map((item, index) => (
                <div key={item.id} className="p-4 border rounded-lg space-y-4">
                  <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                    <h4 className="font-medium">
                      {language === 'ar' ? `البند ${index + 1}` : `Item ${index + 1}`}
                    </h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeInvoiceItem(item.id)}
                      className="text-destructive"
                    >
                      <Trash2 size={16} />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                      <Label>{language === 'ar' ? 'اختيار منتج' : 'Select Product'}</Label>
                      <Select value={item.productId} onValueChange={(value) => selectProduct(item.id, value)}>
                        <SelectTrigger>
                          <SelectValue placeholder={language === 'ar' ? 'اختر منتج' : 'Select product'} />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map(product => (
                            <SelectItem key={product.id} value={product.id.toString()}>
                              {language === 'ar' ? product.name : (product.nameEn || product.name)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>{t('quantity')}</Label>
                      <Input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateInvoiceItem(item.id, 'quantity', parseInt(e.target.value) || 1)}
                      />
                    </div>
                    
                    <div>
                      <Label>{t('price')}</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.price}
                        onChange={(e) => updateInvoiceItem(item.id, 'price', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    
                    <div>
                      <Label>{t('total')}</Label>
                      <Input
                        value={formatCurrency(item.total)}
                        readOnly
                        className="bg-muted"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm text-muted-foreground">{t('cost')}</Label>
                      <div className="text-sm font-medium text-red-600">{formatCurrency(item.cost)}</div>
                    </div>
                    <div>
                      <Label className="text-sm text-muted-foreground">{t('profit')}</Label>
                      <div className="text-sm font-medium text-green-600">{formatCurrency(item.profit)}</div>
                    </div>
                  </div>
                </div>
              ))}
              
              {invoiceItems.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  {language === 'ar' ? 'لم يتم إضافة أي بنود بعد' : 'No items added yet'}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Payment Information */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <CreditCard size={20} />
              {language === 'ar' ? 'معلومات الدفع' : 'Payment Information'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>{t('paymentMethod')}</Label>
                <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                  <SelectTrigger>
                    <SelectValue placeholder={language === 'ar' ? 'اختر طريقة الدفع' : 'Select payment method'} />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map(method => (
                      <SelectItem key={method.value} value={method.value}>
                        {method.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>{language === 'ar' ? 'المبلغ المدفوع' : 'Paid Amount'}</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  placeholder="0.00"
                />
              </div>
            </div>
            
            <div>
              <Label>{language === 'ar' ? 'ملاحظات' : 'Notes'}</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={language === 'ar' ? 'ملاحظات إضافية...' : 'Additional notes...'}
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Invoice Summary */}
        <Card className="financial-card">
          <CardHeader>
            <CardTitle className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              <Calculator size={20} />
              {language === 'ar' ? 'ملخص الفاتورة' : 'Invoice Summary'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className={`flex justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span>{language === 'ar' ? 'المجموع الفرعي' : 'Subtotal'}:</span>
                <span className="font-medium">{formatCurrency(totals.subtotal)}</span>
              </div>
              <div className={`flex justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span>{language === 'ar' ? 'الضريبة' : 'Tax'}:</span>
                <span className="font-medium">{formatCurrency(totals.tax)}</span>
              </div>
              <div className={`flex justify-between text-lg font-bold border-t pt-3 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span>{t('total')}:</span>
                <span className="text-green-600">{formatCurrency(totals.total)}</span>
              </div>
              <div className={`flex justify-between text-lg font-bold text-blue-600 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <span>{language === 'ar' ? 'إجمالي الربح' : 'Total Profit'}:</span>
                <span>{formatCurrency(totals.totalProfit)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className={`flex gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
          <Button type="submit" className="flex-1">
            <Save size={20} className={isRTL ? 'ml-2' : 'mr-2'} />
            {language === 'ar' ? 'حفظ الفاتورة' : 'Save Invoice'}
          </Button>
          <Button type="button" variant="outline" onClick={() => navigate('/invoices')} className="flex-1">
            {t('cancel')}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default CreateInvoice;

