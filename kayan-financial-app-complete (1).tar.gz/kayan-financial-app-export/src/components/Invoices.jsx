import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Eye,
  Edit,
  CreditCard,
  FileText,
  Calendar,
  DollarSign,
  TrendingUp
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const Invoices = () => {
  const { language, formatCurrency, formatDate, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [invoices, setInvoices] = useState([]);
  const [filteredInvoices, setFilteredInvoices] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [paymentMethodFilter, setPaymentMethodFilter] = useState('all');
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');

  useEffect(() => {
    loadInvoices();
  }, []);

  useEffect(() => {
    filterInvoices();
  }, [invoices, searchTerm, statusFilter, paymentMethodFilter]);

  const loadInvoices = () => {
    const invoicesData = dataStore.getInvoices().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    setInvoices(invoicesData);
  };

  const filterInvoices = () => {
    let filtered = invoices;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(invoice => 
        invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        invoice.customerName.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(invoice => invoice.paymentStatus === statusFilter);
    }

    // Payment method filter
    if (paymentMethodFilter !== 'all') {
      filtered = filtered.filter(invoice => invoice.paymentMethod === paymentMethodFilter);
    }

    setFilteredInvoices(filtered);
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      paid: { color: 'bg-green-100 text-green-800', label: t('paid') },
      partial: { color: 'bg-yellow-100 text-yellow-800', label: t('partial') },
      unpaid: { color: 'bg-red-100 text-red-800', label: t('unpaid') }
    };
    
    const config = statusConfig[status] || statusConfig.unpaid;
    return (
      <Badge className={config.color}>
        {config.label}
      </Badge>
    );
  };

  const handlePayment = (invoice) => {
    setSelectedInvoice(invoice);
    setPaymentAmount(invoice.remainingAmount.toString());
    setIsPaymentDialogOpen(true);
  };

  const processPayment = () => {
    if (!selectedInvoice || !paymentAmount) return;

    const amount = parseFloat(paymentAmount);
    const newPaidAmount = selectedInvoice.paidAmount + amount;
    const newRemainingAmount = selectedInvoice.total - newPaidAmount;
    
    const updatedInvoice = {
      ...selectedInvoice,
      paidAmount: newPaidAmount,
      remainingAmount: newRemainingAmount,
      paymentStatus: newRemainingAmount <= 0 ? 'paid' : 'partial'
    };

    dataStore.updateInvoice(selectedInvoice.id, updatedInvoice);
    loadInvoices();
    setIsPaymentDialogOpen(false);
    setPaymentAmount('');
    setSelectedInvoice(null);
  };

  const paymentMethods = [
    { value: 'all', label: language === 'ar' ? 'جميع الطرق' : 'All Methods' },
    { value: 'KHARTOUM_PERSONAL', label: t('KHARTOUM_PERSONAL') },
    { value: 'OMDURMAN_PERSONAL', label: t('OMDURMAN_PERSONAL') },
    { value: 'OMDURMAN_COMPANY', label: t('OMDURMAN_COMPANY') },
    { value: 'cash', label: t('cash') }
  ];

  const statusOptions = [
    { value: 'all', label: language === 'ar' ? 'جميع الحالات' : 'All Status' },
    { value: 'paid', label: t('paid') },
    { value: 'partial', label: t('partial') },
    { value: 'unpaid', label: t('unpaid') }
  ];

  // Calculate summary statistics
  const totalInvoices = invoices.length;
  const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total, 0);
  const totalProfit = invoices.reduce((sum, inv) => sum + inv.totalProfit, 0);
  const paidInvoices = invoices.filter(inv => inv.paymentStatus === 'paid').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('invoices')}</h1>
        <Link to="/create-invoice">
          <Button className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Plus size={20} />
            {t('createInvoice')}
          </Button>
        </Link>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('totalInvoices')}</CardTitle>
            <FileText className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{totalInvoices}</div>
            <p className="text-xs text-muted-foreground">
              {paidInvoices} {language === 'ar' ? 'مدفوع' : 'paid'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('totalRevenue')}</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalRevenue)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'إجمالي المبيعات' : 'total sales'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('totalProfit')}</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalProfit)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'صافي الأرباح' : 'net profits'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'معدل الدفع' : 'Payment Rate'}
            </CardTitle>
            <CreditCard className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {totalInvoices > 0 ? Math.round((paidInvoices / totalInvoices) * 100) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'نسبة الفواتير المدفوعة' : 'paid invoices ratio'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="financial-card">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>{t('search')}</Label>
              <div className="relative">
                <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-muted-foreground`} size={20} />
                <Input
                  placeholder={language === 'ar' ? 'البحث في الفواتير...' : 'Search invoices...'}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`${isRTL ? 'pr-10' : 'pl-10'}`}
                />
              </div>
            </div>
            
            <div>
              <Label>{t('paymentStatus')}</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>{t('paymentMethod')}</Label>
              <Select value={paymentMethodFilter} onValueChange={setPaymentMethodFilter}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map(method => (
                    <SelectItem key={method.value} value={method.value}>
                      {method.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-end">
              <Button variant="outline" className="w-full">
                <Filter size={16} className={isRTL ? 'ml-2' : 'mr-2'} />
                {language === 'ar' ? 'تصفية متقدمة' : 'Advanced Filter'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoices Table */}
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>{language === 'ar' ? 'قائمة الفواتير' : 'Invoices List'}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>{t('invoiceNumber')}</th>
                  <th>{t('customerName')}</th>
                  <th>{t('totalAmount')}</th>
                  <th>{t('netProfit')}</th>
                  <th>{t('paymentMethod')}</th>
                  <th>{t('paymentStatus')}</th>
                  <th>{t('creationDate')}</th>
                  <th>{t('actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredInvoices.map((invoice) => (
                  <tr key={invoice.id}>
                    <td className="font-medium">{invoice.invoiceNumber}</td>
                    <td>{invoice.customerName}</td>
                    <td className="font-semibold text-green-600">{formatCurrency(invoice.total)}</td>
                    <td className="font-semibold text-blue-600">{formatCurrency(invoice.totalProfit)}</td>
                    <td>
                      <span className="text-sm bg-muted px-2 py-1 rounded">
                        {t(invoice.paymentMethod)}
                      </span>
                    </td>
                    <td>{getStatusBadge(invoice.paymentStatus)}</td>
                    <td className="text-sm text-muted-foreground">{formatDate(invoice.createdAt)}</td>
                    <td>
                      <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Eye size={16} />
                        </Button>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <Download size={16} />
                        </Button>
                        {invoice.paymentStatus !== 'paid' && (
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-green-600"
                            onClick={() => handlePayment(invoice)}
                          >
                            <CreditCard size={16} />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {filteredInvoices.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {language === 'ar' ? 'لا توجد فواتير' : 'No invoices found'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {language === 'ar' ? 'تسجيل دفعة' : 'Record Payment'}
            </DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-4">
              <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className={`flex justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="text-sm text-muted-foreground">{t('invoiceNumber')}:</span>
                  <span className="font-medium">{selectedInvoice.invoiceNumber}</span>
                </div>
                <div className={`flex justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="text-sm text-muted-foreground">{t('totalAmount')}:</span>
                  <span className="font-medium">{formatCurrency(selectedInvoice.total)}</span>
                </div>
                <div className={`flex justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="text-sm text-muted-foreground">{language === 'ar' ? 'المبلغ المدفوع' : 'Paid Amount'}:</span>
                  <span className="font-medium text-green-600">{formatCurrency(selectedInvoice.paidAmount)}</span>
                </div>
                <div className={`flex justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <span className="text-sm text-muted-foreground">{language === 'ar' ? 'المبلغ المتبقي' : 'Remaining Amount'}:</span>
                  <span className="font-medium text-red-600">{formatCurrency(selectedInvoice.remainingAmount)}</span>
                </div>
              </div>
              
              <div>
                <Label>{language === 'ar' ? 'مبلغ الدفعة' : 'Payment Amount'}</Label>
                <Input
                  type="number"
                  step="0.01"
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(e.target.value)}
                  placeholder="0.00"
                />
              </div>
              
              <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Button onClick={processPayment} className="flex-1">
                  {language === 'ar' ? 'تسجيل الدفعة' : 'Record Payment'}
                </Button>
                <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)} className="flex-1">
                  {t('cancel')}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Invoices;

