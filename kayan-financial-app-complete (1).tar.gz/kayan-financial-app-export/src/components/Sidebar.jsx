import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { 
  Home, 
  FileText, 
  Users, 
  Truck, 
  CreditCard, 
  BarChart3, 
  Package,
  Globe,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';

function Sidebar() {
  const location = useLocation();
  const { language, toggleLanguage, isRTL } = useLanguage();
  const t = useTranslation(language);

  const menuItems = [
    { path: '/', label: t('dashboard'), icon: Home },
    { path: '/invoices', label: t('invoices'), icon: FileText },
    { path: '/create-invoice', label: t('createInvoice'), icon: FileText },
    { path: '/customers', label: t('customers'), icon: Users },
    { path: '/suppliers', label: t('suppliers'), icon: Truck },
    { path: '/products', label: t('products'), icon: Package },
    { path: '/expenses', label: t('expenses'), icon: CreditCard },
    { path: '/reports', label: t('reports'), icon: BarChart3 },
  ];

  return (
    <div className={`fixed ${isRTL ? 'right-0' : 'left-0'} top-0 h-full w-64 bg-sidebar border-${isRTL ? 'l' : 'r'} border-sidebar-border z-50`}>
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-sidebar-foreground">
            {language === 'ar' ? 'تطبيق كيان' : 'Kayan App'}
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            className="h-8 w-8 p-0"
            title={t('language')}
          >
            <Globe size={16} />
          </Button>
        </div>
        <p className="text-xs text-sidebar-foreground/60 mt-1">
          {language === 'ar' ? 'نظام إدارة مالية' : 'Financial Management System'}
        </p>
      </div>
      
      {/* Navigation */}
      <nav className="p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium transition-colors ${
                    isActive 
                      ? 'bg-primary text-primary-foreground' 
                      : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
                  } ${isRTL ? 'flex-row-reverse' : ''}`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="absolute bottom-4 left-4 right-4">
        <div className="text-xs text-sidebar-foreground/40 text-center">
          {language === 'ar' ? 'إصدار 2.0' : 'Version 2.0'}
        </div>
      </div>
    </div>
  );
}

export default Sidebar;

