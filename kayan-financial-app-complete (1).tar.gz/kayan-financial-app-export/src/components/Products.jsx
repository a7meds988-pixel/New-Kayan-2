import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Plus, 
  Search, 
  Edit, 
  Trash2,
  Package,
  DollarSign,
  TrendingUp
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const Products = () => {
  const { language, formatCurrency, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    nameEn: '',
    price: '',
    cost: '',
    category: ''
  });

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = () => {
    setProducts(dataStore.getProducts());
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const productData = {
      name: formData.name,
      nameEn: formData.nameEn,
      price: parseFloat(formData.price),
      cost: parseFloat(formData.cost),
      category: formData.category
    };

    if (editingProduct) {
      dataStore.updateProduct(editingProduct.id, productData);
    } else {
      dataStore.addProduct(productData);
    }

    loadProducts();
    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      nameEn: '',
      price: '',
      cost: '',
      category: ''
    });
    setEditingProduct(null);
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      nameEn: product.nameEn || '',
      price: product.price.toString(),
      cost: product.cost.toString(),
      category: product.category || ''
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    if (window.confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا المنتج؟' : 'Are you sure you want to delete this product?')) {
      dataStore.deleteProduct(id);
      loadProducts();
    }
  };

  const filteredProducts = products.filter(product => {
    const name = language === 'ar' ? product.name : (product.nameEn || product.name);
    return name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const totalProducts = products.length;
  const totalValue = products.reduce((sum, product) => sum + product.price, 0);
  const totalProfit = products.reduce((sum, product) => sum + (product.price - product.cost), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('products')}</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`} onClick={resetForm}>
              <Plus size={20} />
              {t('addProduct')}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? 
                  (language === 'ar' ? 'تعديل المنتج' : 'Edit Product') : 
                  t('addProduct')
                }
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">
                  {language === 'ar' ? 'اسم المنتج (عربي)' : 'Product Name (Arabic)'}
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  dir="rtl"
                />
              </div>
              <div>
                <Label htmlFor="nameEn">
                  {language === 'ar' ? 'اسم المنتج (إنجليزي)' : 'Product Name (English)'}
                </Label>
                <Input
                  id="nameEn"
                  value={formData.nameEn}
                  onChange={(e) => setFormData({...formData, nameEn: e.target.value})}
                  dir="ltr"
                />
              </div>
              <div>
                <Label htmlFor="price">{t('price')}</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="cost">{t('cost')}</Label>
                <Input
                  id="cost"
                  type="number"
                  step="0.01"
                  value={formData.cost}
                  onChange={(e) => setFormData({...formData, cost: e.target.value})}
                  required
                />
              </div>
              <div>
                <Label htmlFor="category">
                  {language === 'ar' ? 'الفئة' : 'Category'}
                </Label>
                <Input
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                />
              </div>
              <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Button type="submit" className="flex-1">
                  {t('save')}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1"
                >
                  {t('cancel')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي المنتجات' : 'Total Products'}
            </CardTitle>
            <Package className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{totalProducts}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'منتج محفوظ' : 'saved products'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي القيمة' : 'Total Value'}
            </CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalValue)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'قيمة جميع المنتجات' : 'value of all products'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي الربح المتوقع' : 'Expected Profit'}
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalProfit)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'ربح متوقع لكل وحدة' : 'expected profit per unit'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="financial-card">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-muted-foreground`} size={20} />
            <Input
              placeholder={t('search')}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`${isRTL ? 'pr-10' : 'pl-10'}`}
            />
          </div>
        </CardContent>
      </Card>

      {/* Products Table */}
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>{language === 'ar' ? 'قائمة المنتجات' : 'Products List'}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>{t('productName')}</th>
                  <th>{t('price')}</th>
                  <th>{t('cost')}</th>
                  <th>{t('profit')}</th>
                  <th>{language === 'ar' ? 'الفئة' : 'Category'}</th>
                  <th>{t('actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product) => {
                  const profit = product.price - product.cost;
                  const profitMargin = ((profit / product.price) * 100).toFixed(1);
                  const displayName = language === 'ar' ? product.name : (product.nameEn || product.name);
                  
                  return (
                    <tr key={product.id}>
                      <td className="font-medium">{displayName}</td>
                      <td className="font-semibold text-green-600">{formatCurrency(product.price)}</td>
                      <td className="text-red-600">{formatCurrency(product.cost)}</td>
                      <td className="font-semibold text-blue-600">
                        {formatCurrency(profit)}
                        <span className="text-xs text-muted-foreground ml-1">
                          ({profitMargin}%)
                        </span>
                      </td>
                      <td>{product.category || '-'}</td>
                      <td>
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleEdit(product)}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-destructive"
                            onClick={() => handleDelete(product.id)}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {language === 'ar' ? 'لا توجد منتجات' : 'No products found'}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Products;

