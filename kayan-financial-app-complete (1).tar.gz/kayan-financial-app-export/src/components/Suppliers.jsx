import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Plus, 
  Search, 
  Truck, 
  Package,
  FileText,
  Building
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const Suppliers = () => {
  const { language, formatCurrency, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [suppliers, setSuppliers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    nameEn: '',
    email: '',
    phone: '',
    address: '',
    addressEn: '',
    category: ''
  });

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = () => {
    // Load suppliers from localStorage or initialize with sample data
    const savedSuppliers = JSON.parse(localStorage.getItem('kayan_suppliers') || '[]');
    if (savedSuppliers.length === 0) {
      const sampleSuppliers = [
        {
          id: 1,
          name: 'شركة التقنية المتقدمة',
          nameEn: 'Advanced Technology Company',
          email: 'info@advtech.com',
          phone: '+249123456789',
          address: 'الخرطوم، السودان',
          addressEn: 'Khartoum, Sudan',
          category: 'electronics',
          createdAt: new Date().toISOString()
        },
        {
          id: 2,
          name: 'مؤسسة الإمدادات التجارية',
          nameEn: 'Commercial Supplies Corporation',
          email: 'sales@comsupply.com',
          phone: '+249987654321',
          address: 'أمدرمان، السودان',
          addressEn: 'Omdurman, Sudan',
          category: 'general',
          createdAt: new Date().toISOString()
        }
      ];
      setSuppliers(sampleSuppliers);
      localStorage.setItem('kayan_suppliers', JSON.stringify(sampleSuppliers));
    } else {
      setSuppliers(savedSuppliers);
    }
  };

  const saveSuppliers = (suppliersData) => {
    localStorage.setItem('kayan_suppliers', JSON.stringify(suppliersData));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newSupplier = {
      ...formData,
      id: Date.now(),
      createdAt: new Date().toISOString()
    };

    const updatedSuppliers = [...suppliers, newSupplier];
    setSuppliers(updatedSuppliers);
    saveSuppliers(updatedSuppliers);
    
    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      nameEn: '',
      email: '',
      phone: '',
      address: '',
      addressEn: '',
      category: ''
    });
  };

  const filteredSuppliers = suppliers.filter(supplier => {
    const name = language === 'ar' ? supplier.name : (supplier.nameEn || supplier.name);
    return name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           (supplier.email && supplier.email.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('suppliers')}</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`} onClick={resetForm}>
              <Plus size={20} />
              {language === 'ar' ? 'إضافة مورد' : 'Add Supplier'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {language === 'ar' ? 'إضافة مورد جديد' : 'Add New Supplier'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>{language === 'ar' ? 'اسم المورد (عربي)' : 'Supplier Name (Arabic)'}</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  dir="rtl"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'اسم المورد (إنجليزي)' : 'Supplier Name (English)'}</Label>
                <Input
                  value={formData.nameEn}
                  onChange={(e) => setFormData({...formData, nameEn: e.target.value})}
                  dir="ltr"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'رقم الهاتف' : 'Phone'}</Label>
                <Input
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'العنوان (عربي)' : 'Address (Arabic)'}</Label>
                <Input
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  dir="rtl"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'فئة المورد' : 'Supplier Category'}</Label>
                <Input
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  placeholder={language === 'ar' ? 'مثل: إلكترونيات، مواد غذائية' : 'e.g: Electronics, Food'}
                />
              </div>
              <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Button type="submit" className="flex-1">{t('save')}</Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                  {t('cancel')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي الموردين' : 'Total Suppliers'}
            </CardTitle>
            <Building className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{suppliers.length}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'مورد مسجل' : 'registered suppliers'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'فواتير الشراء' : 'Purchase Orders'}
            </CardTitle>
            <FileText className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">0</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'فاتورة شراء' : 'purchase orders'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي المشتريات' : 'Total Purchases'}
            </CardTitle>
            <Package className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(0)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'قيمة المشتريات' : 'purchase value'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="financial-card">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-muted-foreground`} size={20} />
            <Input
              placeholder={language === 'ar' ? 'البحث في الموردين...' : 'Search suppliers...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`${isRTL ? 'pr-10' : 'pl-10'}`}
            />
          </div>
        </CardContent>
      </Card>

      {/* Suppliers Table */}
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>{language === 'ar' ? 'قائمة الموردين' : 'Suppliers List'}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>{language === 'ar' ? 'اسم المورد' : 'Supplier Name'}</th>
                  <th>{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</th>
                  <th>{language === 'ar' ? 'رقم الهاتف' : 'Phone'}</th>
                  <th>{language === 'ar' ? 'الفئة' : 'Category'}</th>
                  <th>{language === 'ar' ? 'العنوان' : 'Address'}</th>
                  <th>{language === 'ar' ? 'فواتير الشراء' : 'Purchase Orders'}</th>
                </tr>
              </thead>
              <tbody>
                {filteredSuppliers.map((supplier) => {
                  const displayName = language === 'ar' ? supplier.name : (supplier.nameEn || supplier.name);
                  const displayAddress = language === 'ar' ? supplier.address : (supplier.addressEn || supplier.address);
                  
                  return (
                    <tr key={supplier.id}>
                      <td className="font-medium">{displayName}</td>
                      <td className="text-sm text-muted-foreground">{supplier.email || '-'}</td>
                      <td className="text-sm">{supplier.phone || '-'}</td>
                      <td>
                        <span className="text-sm bg-muted px-2 py-1 rounded">
                          {supplier.category || '-'}
                        </span>
                      </td>
                      <td className="text-sm text-muted-foreground">{displayAddress || '-'}</td>
                      <td className="text-center">
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                          0
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredSuppliers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {language === 'ar' ? 'لا توجد موردين' : 'No suppliers found'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="financial-card border-blue-200 bg-blue-50">
        <CardContent className="pt-6">
          <div className={`flex items-start gap-4 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <Truck className="h-8 w-8 text-blue-600 mt-1" />
            <div className={isRTL ? 'text-right' : 'text-left'}>
              <h3 className="font-semibold text-blue-900 mb-2">
                {language === 'ar' ? 'معلومات حول الموردين' : 'About Suppliers'}
              </h3>
              <p className="text-sm text-blue-700 leading-relaxed">
                {language === 'ar' ? 
                  'صفحة الموردين مخصصة لإدارة قاعدة بيانات الموردين فقط. فواتير الشراء من الموردين يتم تسجيلها في قسم التقارير ولا ترتبط بحسابات الأرباح أو المصروفات الشخصية.' :
                  'The Suppliers page is dedicated to managing the supplier database only. Purchase invoices from suppliers are recorded in the reports section and are not linked to profit accounts or personal expenses.'
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Suppliers;

