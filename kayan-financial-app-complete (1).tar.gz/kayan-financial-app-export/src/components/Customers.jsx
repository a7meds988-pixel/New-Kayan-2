import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useTranslation } from '../utils/translations';
import { dataStore } from '../utils/dataStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Plus, 
  Search, 
  Eye, 
  Edit, 
  Trash2,
  Users,
  DollarSign,
  TrendingUp,
  FileText,
  Download,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const Customers = () => {
  const { language, formatCurrency, formatDate, isRTL } = useLanguage();
  const t = useTranslation(language);
  const [customers, setCustomers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [customerAnalytics, setCustomerAnalytics] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    nameEn: '',
    email: '',
    phone: '',
    address: '',
    addressEn: ''
  });

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = () => {
    setCustomers(dataStore.getCustomers());
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingCustomer) {
      dataStore.updateCustomer(editingCustomer.id, formData);
    } else {
      dataStore.addCustomer(formData);
    }

    loadCustomers();
    resetForm();
    setIsDialogOpen(false);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      nameEn: '',
      email: '',
      phone: '',
      address: '',
      addressEn: ''
    });
    setEditingCustomer(null);
  };

  const handleEdit = (customer) => {
    setEditingCustomer(customer);
    setFormData({
      name: customer.name,
      nameEn: customer.nameEn || '',
      email: customer.email || '',
      phone: customer.phone || '',
      address: customer.address || '',
      addressEn: customer.addressEn || ''
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id) => {
    if (window.confirm(language === 'ar' ? 'هل أنت متأكد من حذف هذا العميل؟' : 'Are you sure you want to delete this customer?')) {
      dataStore.deleteCustomer(id);
      loadCustomers();
    }
  };

  const viewCustomerDetails = (customer) => {
    setSelectedCustomer(customer);
    const analytics = dataStore.getCustomerAnalytics(customer.id);
    setCustomerAnalytics(analytics);
    setIsDetailDialogOpen(true);
  };

  const filteredCustomers = customers.filter(customer => {
    const name = language === 'ar' ? customer.name : (customer.nameEn || customer.name);
    return name.toLowerCase().includes(searchTerm.toLowerCase()) ||
           (customer.email && customer.email.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  // Calculate summary statistics
  const totalCustomers = customers.length;
  const activeCustomers = customers.filter(customer => {
    const analytics = dataStore.getCustomerAnalytics(customer.id);
    return analytics.totalInvoices > 0;
  }).length;

  const totalCustomerValue = customers.reduce((sum, customer) => {
    const analytics = dataStore.getCustomerAnalytics(customer.id);
    return sum + analytics.totalAmount;
  }, 0);

  const totalCustomerProfit = customers.reduce((sum, customer) => {
    const analytics = dataStore.getCustomerAnalytics(customer.id);
    return sum + analytics.totalProfit;
  }, 0);

  // Generate monthly chart data for selected customer
  const generateCustomerChartData = (invoices) => {
    const monthlyData = {};
    
    invoices.forEach(invoice => {
      const month = new Date(invoice.createdAt).toISOString().slice(0, 7);
      if (!monthlyData[month]) {
        monthlyData[month] = { sales: 0, profit: 0 };
      }
      monthlyData[month].sales += invoice.total;
      monthlyData[month].profit += invoice.totalProfit;
    });

    return Object.entries(monthlyData)
      .map(([month, data]) => ({
        month: new Date(month + '-01').toLocaleDateString(language === 'ar' ? 'ar-SD' : 'en-US', { month: 'short' }),
        sales: data.sales,
        profit: data.profit
      }))
      .slice(-6); // Last 6 months
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className={`flex items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
        <h1 className="text-3xl font-bold">{t('customers')}</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`} onClick={resetForm}>
              <Plus size={20} />
              {language === 'ar' ? 'إضافة عميل' : 'Add Customer'}
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingCustomer ? 
                  (language === 'ar' ? 'تعديل العميل' : 'Edit Customer') : 
                  (language === 'ar' ? 'إضافة عميل جديد' : 'Add New Customer')
                }
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>{language === 'ar' ? 'الاسم (عربي)' : 'Name (Arabic)'}</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  required
                  dir="rtl"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'الاسم (إنجليزي)' : 'Name (English)'}</Label>
                <Input
                  value={formData.nameEn}
                  onChange={(e) => setFormData({...formData, nameEn: e.target.value})}
                  dir="ltr"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'رقم الهاتف' : 'Phone'}</Label>
                <Input
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'العنوان (عربي)' : 'Address (Arabic)'}</Label>
                <Input
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  dir="rtl"
                />
              </div>
              <div>
                <Label>{language === 'ar' ? 'العنوان (إنجليزي)' : 'Address (English)'}</Label>
                <Input
                  value={formData.addressEn}
                  onChange={(e) => setFormData({...formData, addressEn: e.target.value})}
                  dir="ltr"
                />
              </div>
              <div className={`flex gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                <Button type="submit" className="flex-1">{t('save')}</Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                  {t('cancel')}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">{t('totalCustomers')}</CardTitle>
            <Users className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{totalCustomers}</div>
            <p className="text-xs text-muted-foreground">
              {activeCustomers} {language === 'ar' ? 'نشط' : 'active'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي قيمة العملاء' : 'Total Customer Value'}
            </CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalCustomerValue)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'إجمالي المبيعات' : 'total sales'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'إجمالي الأرباح' : 'Total Profit'}
            </CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{formatCurrency(totalCustomerProfit)}</div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'من جميع العملاء' : 'from all customers'}
            </p>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardHeader className={`flex flex-row items-center justify-between space-y-0 pb-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
            <CardTitle className="text-sm font-medium">
              {language === 'ar' ? 'متوسط قيمة العميل' : 'Average Customer Value'}
            </CardTitle>
            <FileText className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {formatCurrency(totalCustomers > 0 ? totalCustomerValue / totalCustomers : 0)}
            </div>
            <p className="text-xs text-muted-foreground">
              {language === 'ar' ? 'متوسط المبيعات' : 'average sales'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="financial-card">
        <CardContent className="pt-6">
          <div className="relative">
            <Search className={`absolute ${isRTL ? 'right-3' : 'left-3'} top-1/2 transform -translate-y-1/2 text-muted-foreground`} size={20} />
            <Input
              placeholder={language === 'ar' ? 'البحث في العملاء...' : 'Search customers...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`${isRTL ? 'pr-10' : 'pl-10'}`}
            />
          </div>
        </CardContent>
      </Card>

      {/* Customers Table */}
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>{t('customerList')}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>{t('customerName')}</th>
                  <th>{language === 'ar' ? 'البريد الإلكتروني' : 'Email'}</th>
                  <th>{language === 'ar' ? 'رقم الهاتف' : 'Phone'}</th>
                  <th>{language === 'ar' ? 'عدد الفواتير' : 'Invoices'}</th>
                  <th>{language === 'ar' ? 'إجمالي المبيعات' : 'Total Sales'}</th>
                  <th>{language === 'ar' ? 'إجمالي الأرباح' : 'Total Profit'}</th>
                  <th>{t('actions')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredCustomers.map((customer) => {
                  const analytics = dataStore.getCustomerAnalytics(customer.id);
                  const displayName = language === 'ar' ? customer.name : (customer.nameEn || customer.name);
                  
                  return (
                    <tr key={customer.id}>
                      <td className="font-medium">{displayName}</td>
                      <td className="text-sm text-muted-foreground">{customer.email || '-'}</td>
                      <td className="text-sm">{customer.phone || '-'}</td>
                      <td className="text-center">
                        <span className="bg-primary/10 text-primary px-2 py-1 rounded text-sm">
                          {analytics.totalInvoices}
                        </span>
                      </td>
                      <td className="font-semibold text-green-600">{formatCurrency(analytics.totalAmount)}</td>
                      <td className="font-semibold text-blue-600">{formatCurrency(analytics.totalProfit)}</td>
                      <td>
                        <div className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => viewCustomerDetails(customer)}
                          >
                            <Eye size={16} />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleEdit(customer)}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-destructive"
                            onClick={() => handleDelete(customer.id)}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          
          {filteredCustomers.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              {language === 'ar' ? 'لا توجد عملاء' : 'No customers found'}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Customer Details Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className={`flex items-center gap-2 ${isRTL ? 'flex-row-reverse' : ''}`}>
              {isRTL ? <ArrowLeft size={20} /> : <ArrowRight size={20} />}
              {selectedCustomer && (language === 'ar' ? selectedCustomer.name : (selectedCustomer.nameEn || selectedCustomer.name))}
            </DialogTitle>
          </DialogHeader>
          
          {selectedCustomer && customerAnalytics && (
            <div className="space-y-6">
              {/* Customer Summary */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">{customerAnalytics.totalInvoices}</div>
                      <p className="text-sm text-muted-foreground">{t('customerInvoices')}</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{formatCurrency(customerAnalytics.totalAmount)}</div>
                      <p className="text-sm text-muted-foreground">{t('customerTotal')}</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">{formatCurrency(customerAnalytics.totalProfit)}</div>
                      <p className="text-sm text-muted-foreground">{t('customerProfit')}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Monthly Chart */}
              {customerAnalytics.invoices.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>{t('monthlySalesChart')}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={generateCustomerChartData(customerAnalytics.invoices)}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis />
                        <Tooltip 
                          formatter={(value) => formatCurrency(value)}
                          labelStyle={{ direction: isRTL ? 'rtl' : 'ltr' }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="sales" 
                          stroke="#10b981" 
                          strokeWidth={2}
                          name={language === 'ar' ? 'المبيعات' : 'Sales'}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="profit" 
                          stroke="#3b82f6" 
                          strokeWidth={2}
                          name={language === 'ar' ? 'الأرباح' : 'Profit'}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}

              {/* Customer Invoices */}
              <Card>
                <CardHeader className={`flex flex-row items-center justify-between ${isRTL ? 'flex-row-reverse' : ''}`}>
                  <CardTitle>{t('customerInvoices')}</CardTitle>
                  <Button variant="outline" size="sm">
                    <Download size={16} className={isRTL ? 'ml-2' : 'mr-2'} />
                    {t('downloadCustomerInvoices')}
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {customerAnalytics.invoices.slice(0, 5).map((invoice) => (
                      <div key={invoice.id} className={`flex items-center justify-between p-3 rounded-md bg-muted/50 ${isRTL ? 'flex-row-reverse' : ''}`}>
                        <div className={isRTL ? 'text-right' : 'text-left'}>
                          <p className="font-medium text-sm">{invoice.invoiceNumber}</p>
                          <p className="text-xs text-muted-foreground">{formatDate(invoice.createdAt)}</p>
                        </div>
                        <div className={`text-right ${isRTL ? 'text-left' : ''}`}>
                          <p className="font-semibold text-sm text-green-600">{formatCurrency(invoice.total)}</p>
                          <p className="text-xs text-blue-600">{formatCurrency(invoice.totalProfit)} {language === 'ar' ? 'ربح' : 'profit'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Customers;

