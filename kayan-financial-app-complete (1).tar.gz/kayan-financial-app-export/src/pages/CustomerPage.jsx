import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function CustomerPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">العملاء</h1>
      </div>
      
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>قائمة العملاء</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            هنا ستظهر جميع العملاء الخاصين بك
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default CustomerPage;

