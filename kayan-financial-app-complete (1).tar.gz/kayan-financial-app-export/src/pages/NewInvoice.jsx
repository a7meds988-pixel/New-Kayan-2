import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function NewInvoice() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">إنشاء فاتورة جديدة</h1>
      </div>
      
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>نموذج الفاتورة</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            هنا يمكنك إنشاء فاتورة جديدة
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default NewInvoice;

