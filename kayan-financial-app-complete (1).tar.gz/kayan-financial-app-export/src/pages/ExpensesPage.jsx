import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function ExpensesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">المصروفات</h1>
      </div>
      
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>قائمة المصروفات</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            هنا ستظهر جميع المصروفات الخاصة بك
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default ExpensesPage;

