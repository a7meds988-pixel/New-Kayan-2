import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

function SupplierPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">الموردين</h1>
      </div>
      
      <Card className="financial-card">
        <CardHeader>
          <CardTitle>قائمة الموردين</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            هنا ستظهر جميع الموردين الخاصين بك
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default SupplierPage;

