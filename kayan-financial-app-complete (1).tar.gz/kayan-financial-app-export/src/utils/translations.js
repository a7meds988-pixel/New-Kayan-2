export const translations = {
  ar: {
    // Navigation
    dashboard: 'الصفحة الرئيسية',
    invoices: 'الفواتير',
    customers: 'العملاء',
    suppliers: 'الموردين',
    expenses: 'المصروفات',
    reports: 'التقارير',
    products: 'المنتجات',
    
    // Dashboard
    totalRevenue: 'إجمالي الإيرادات',
    totalInvoices: 'إجمالي الفواتير',
    totalProfit: 'إجمالي الأرباح',
    totalSales: 'إجمالي المبيعات',
    totalCustomers: 'عدد العملاء',
    growthRate: 'معدل النمو',
    monthlyReports: 'التقارير الشهرية',
    quickNavigation: 'التنقل السريع',
    
    // Invoices
    createInvoice: 'إنشاء فاتورة جديدة',
    invoiceNumber: 'رقم الفاتورة',
    customerName: 'اسم العميل',
    totalAmount: 'إجمالي المبلغ',
    creationDate: 'تاريخ الإنشاء',
    paymentMethod: 'طريقة الدفع',
    paymentStatus: 'حالة الدفع',
    netProfit: 'صافي الربح',
    downloadPDF: 'تحميل PDF',
    
    // Payment Status
    paid: 'مدفوع',
    partial: 'جزئي',
    unpaid: 'غير مدفوع',
    
    // Payment Methods / Bank Accounts
    KHARTOUM_PERSONAL: 'حسابك الشخصي - بنك الخرطوم',
    OMDURMAN_PERSONAL: 'حسابك الشخصي - بنك أمدرمان',
    OMDURMAN_COMPANY: 'حساب الشركة - بنك أمدرمان',
    cash: 'نقدي',
    
    // Products
    productName: 'اسم المنتج',
    price: 'السعر',
    cost: 'التكلفة',
    profit: 'الربح',
    quantity: 'الكمية',
    total: 'المجموع',
    addProduct: 'إضافة منتج',
    saveProduct: 'حفظ المنتج',
    selectProduct: 'اختيار منتج',
    
    // Customers
    customerList: 'قائمة العملاء',
    customerInvoices: 'فواتير العميل',
    customerTotal: 'مجموع فواتير العميل',
    customerProfit: 'أرباحك من هذا العميل',
    monthlySalesChart: 'رسم بياني شهري للمبيعات والأرباح',
    downloadCustomerInvoices: 'تحميل فواتير العميل مجمعة',
    
    // Expenses
    personalExpenses: 'مصروفاتي الشخصية',
    wifeExpenses: 'مصروفات زوجتي (دعاء)',
    expenseType: 'نوع المصروف',
    expenseAmount: 'مبلغ المصروف',
    expenseDate: 'تاريخ المصروف',
    expenseDescription: 'وصف المصروف',
    filterByMonth: 'تصفية حسب الشهر',
    filterByType: 'تصفية حسب النوع',
    
    // Reports
    detailedReports: 'تقارير تفصيلية',
    revenue: 'الإيرادات',
    expenses: 'المصروفات',
    netProfits: 'الأرباح الصافية',
    profitsByCustomer: 'الأرباح حسب العملاء',
    profitsByProduct: 'الأرباح حسب البنود',
    monthlyComparison: 'مقارنة شهرية',
    salesAndProfits: 'المبيعات والأرباح',
    
    // Common
    add: 'إضافة',
    edit: 'تعديل',
    delete: 'حذف',
    save: 'حفظ',
    cancel: 'إلغاء',
    search: 'البحث',
    filter: 'تصفية',
    export: 'تصدير',
    print: 'طباعة',
    view: 'عرض',
    details: 'التفاصيل',
    actions: 'الإجراءات',
    date: 'التاريخ',
    amount: 'المبلغ',
    description: 'الوصف',
    status: 'الحالة',
    type: 'النوع',
    
    // Settings
    language: 'اللغة',
    currency: 'العملة',
    settings: 'الإعدادات',
    arabic: 'العربية',
    english: 'الإنجليزية'
  },
  
  en: {
    // Navigation
    dashboard: 'Dashboard',
    invoices: 'Invoices',
    customers: 'Customers',
    suppliers: 'Suppliers',
    expenses: 'Expenses',
    reports: 'Reports',
    products: 'Products',
    
    // Dashboard
    totalRevenue: 'Total Revenue',
    totalInvoices: 'Total Invoices',
    totalProfit: 'Total Profit',
    totalSales: 'Total Sales',
    totalCustomers: 'Total Customers',
    growthRate: 'Growth Rate',
    monthlyReports: 'Monthly Reports',
    quickNavigation: 'Quick Navigation',
    
    // Invoices
    createInvoice: 'Create New Invoice',
    invoiceNumber: 'Invoice Number',
    customerName: 'Customer Name',
    totalAmount: 'Total Amount',
    creationDate: 'Creation Date',
    paymentMethod: 'Payment Method',
    paymentStatus: 'Payment Status',
    netProfit: 'Net Profit',
    downloadPDF: 'Download PDF',
    
    // Payment Status
    paid: 'Paid',
    partial: 'Partial',
    unpaid: 'Unpaid',
    
    // Payment Methods / Bank Accounts
    KHARTOUM_PERSONAL: 'Personal Account - Khartoum Bank',
    OMDURMAN_PERSONAL: 'Personal Account - Omdurman Bank',
    OMDURMAN_COMPANY: 'Company Account - Omdurman Bank',
    cash: 'Cash',
    
    // Products
    productName: 'Product Name',
    price: 'Price',
    cost: 'Cost',
    profit: 'Profit',
    quantity: 'Quantity',
    total: 'Total',
    addProduct: 'Add Product',
    saveProduct: 'Save Product',
    selectProduct: 'Select Product',
    
    // Customers
    customerList: 'Customer List',
    customerInvoices: 'Customer Invoices',
    customerTotal: 'Customer Total',
    customerProfit: 'Your Profit from this Customer',
    monthlySalesChart: 'Monthly Sales and Profit Chart',
    downloadCustomerInvoices: 'Download Customer Invoices Bundle',
    
    // Expenses
    personalExpenses: 'My Personal Expenses',
    wifeExpenses: 'Wife Expenses (Duaa)',
    expenseType: 'Expense Type',
    expenseAmount: 'Expense Amount',
    expenseDate: 'Expense Date',
    expenseDescription: 'Expense Description',
    filterByMonth: 'Filter by Month',
    filterByType: 'Filter by Type',
    
    // Reports
    detailedReports: 'Detailed Reports',
    revenue: 'Revenue',
    expenses: 'Expenses',
    netProfits: 'Net Profits',
    profitsByCustomer: 'Profits by Customer',
    profitsByProduct: 'Profits by Product',
    monthlyComparison: 'Monthly Comparison',
    salesAndProfits: 'Sales and Profits',
    
    // Common
    add: 'Add',
    edit: 'Edit',
    delete: 'Delete',
    save: 'Save',
    cancel: 'Cancel',
    search: 'Search',
    filter: 'Filter',
    export: 'Export',
    print: 'Print',
    view: 'View',
    details: 'Details',
    actions: 'Actions',
    date: 'Date',
    amount: 'Amount',
    description: 'Description',
    status: 'Status',
    type: 'Type',
    
    // Settings
    language: 'Language',
    currency: 'Currency',
    settings: 'Settings',
    arabic: 'Arabic',
    english: 'English'
  }
}

export const useTranslation = (language) => {
  return (key) => {
    return translations[language]?.[key] || key
  }
}

