// Utility to clear all application data

export const clearAllData = () => {
  // Clear all localStorage keys that start with 'kayan_'
  Object.keys(localStorage).forEach(key => {
    if (key.startsWith('kayan_')) {
      localStorage.removeItem(key);
    }
  });
  
  // Also clear any other related keys
  localStorage.removeItem('language');
  localStorage.removeItem('theme');
  
  console.log('All application data cleared');
};

export const resetToCleanState = () => {
  clearAllData();
  
  // Initialize empty data structures
  localStorage.setItem('kayan_products', JSON.stringify([]));
  localStorage.setItem('kayan_customers', JSON.stringify([]));
  localStorage.setItem('kayan_invoices', JSON.stringify([]));
  localStorage.setItem('kayan_expenses', JSON.stringify([]));
  localStorage.setItem('kayan_suppliers', JSON.stringify([]));
  
  console.log('Application reset to clean state');
};

// Auto-clear on first load (for clean deployment)
if (typeof window !== 'undefined') {
  // Check if this is a fresh deployment
  const isFirstLoad = !localStorage.getItem('kayan_initialized');
  
  if (isFirstLoad) {
    resetToCleanState();
    localStorage.setItem('kayan_initialized', 'true');
  }
}

