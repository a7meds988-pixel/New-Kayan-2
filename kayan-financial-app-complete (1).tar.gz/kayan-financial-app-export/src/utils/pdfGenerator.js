import jsPDF from 'jspdf';
import 'jspdf-autotable';

// Add Arabic font support
const addArabicFont = (doc) => {
  // This would normally load an Arabic font
  // For now, we'll use the default font with RTL support
  doc.setFont('helvetica');
};

export const generateInvoicePDF = (invoice, customer, language = 'ar') => {
  const doc = new jsPDF();
  const isRTL = language === 'ar';
  
  // Add Arabic font support
  addArabicFont(doc);
  
  // Page dimensions
  const pageWidth = doc.internal.pageSize.width;
  const pageHeight = doc.internal.pageSize.height;
  const margin = 20;
  
  // Colors
  const primaryColor = [59, 130, 246]; // Blue
  const secondaryColor = [107, 114, 128]; // Gray
  const accentColor = [16, 185, 129]; // Green
  
  // Helper function to format currency
  const formatCurrency = (amount) => {
    return language === 'ar' ? 
      `${amount.toLocaleString('ar-SD')} ج.س` : 
      `SDG ${amount.toLocaleString('en-US')}`;
  };
  
  // Helper function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return language === 'ar' ? 
      date.toLocaleDateString('ar-SD') : 
      date.toLocaleDateString('en-US');
  };
  
  // Header Section
  let yPos = margin;
  
  // Company Logo Area (placeholder)
  doc.setFillColor(...primaryColor);
  doc.rect(margin, yPos, 60, 30, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  
  if (isRTL) {
    doc.text('كيان', margin + 30, yPos + 20, { align: 'center' });
  } else {
    doc.text('KAYAN', margin + 30, yPos + 20, { align: 'center' });
  }
  
  // Company Info
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  const companyInfo = language === 'ar' ? [
    'نظام إدارة مالية',
    'الخرطوم، السودان',
    'هاتف: +249123456789',
    'البريد: info@kayan.sd'
  ] : [
    'Financial Management System',
    'Khartoum, Sudan',
    'Phone: +249123456789',
    'Email: info@kayan.sd'
  ];
  
  companyInfo.forEach((line, index) => {
    if (isRTL) {
      doc.text(line, pageWidth - margin, yPos + 5 + (index * 5), { align: 'right' });
    } else {
      doc.text(line, pageWidth - margin, yPos + 5 + (index * 5), { align: 'right' });
    }
  });
  
  yPos += 50;
  
  // Invoice Title
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(...primaryColor);
  
  const invoiceTitle = language === 'ar' ? 'فاتورة' : 'INVOICE';
  if (isRTL) {
    doc.text(invoiceTitle, pageWidth - margin, yPos, { align: 'right' });
  } else {
    doc.text(invoiceTitle, margin, yPos);
  }
  
  yPos += 20;
  
  // Invoice Details Box
  doc.setFillColor(248, 250, 252);
  doc.rect(margin, yPos, pageWidth - (2 * margin), 30, 'F');
  doc.setDrawColor(...secondaryColor);
  doc.rect(margin, yPos, pageWidth - (2 * margin), 30);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  
  // Invoice details
  const invoiceDetails = [
    { 
      label: language === 'ar' ? 'رقم الفاتورة:' : 'Invoice Number:', 
      value: invoice.invoiceNumber 
    },
    { 
      label: language === 'ar' ? 'تاريخ الإصدار:' : 'Issue Date:', 
      value: formatDate(invoice.createdAt) 
    },
    { 
      label: language === 'ar' ? 'تاريخ الاستحقاق:' : 'Due Date:', 
      value: formatDate(invoice.dueDate) 
    },
    { 
      label: language === 'ar' ? 'حالة الدفع:' : 'Payment Status:', 
      value: language === 'ar' ? 
        (invoice.paymentStatus === 'paid' ? 'مدفوع' : 
         invoice.paymentStatus === 'partial' ? 'جزئي' : 'غير مدفوع') :
        invoice.paymentStatus.toUpperCase()
    }
  ];
  
  invoiceDetails.forEach((detail, index) => {
    const xPos = isRTL ? pageWidth - margin - 5 : margin + 5;
    const textAlign = isRTL ? 'right' : 'left';
    
    doc.text(detail.label, xPos, yPos + 8 + (index * 5), { align: textAlign });
    doc.setFont('helvetica', 'normal');
    doc.text(detail.value, xPos + (isRTL ? -60 : 60), yPos + 8 + (index * 5), { align: textAlign });
    doc.setFont('helvetica', 'bold');
  });
  
  yPos += 50;
  
  // Customer Information
  doc.setFillColor(...primaryColor);
  doc.rect(margin, yPos, pageWidth - (2 * margin), 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  
  const billToTitle = language === 'ar' ? 'فاتورة إلى:' : 'BILL TO:';
  if (isRTL) {
    doc.text(billToTitle, pageWidth - margin - 5, yPos + 6, { align: 'right' });
  } else {
    doc.text(billToTitle, margin + 5, yPos + 6);
  }
  
  yPos += 15;
  
  // Customer details
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  
  const customerName = language === 'ar' ? customer.name : (customer.nameEn || customer.name);
  const customerAddress = language === 'ar' ? customer.address : (customer.addressEn || customer.address);
  
  const customerDetails = [
    customerName,
    customer.email || '',
    customer.phone || '',
    customerAddress || ''
  ].filter(detail => detail);
  
  customerDetails.forEach((detail, index) => {
    if (isRTL) {
      doc.text(detail, pageWidth - margin - 5, yPos + (index * 5), { align: 'right' });
    } else {
      doc.text(detail, margin + 5, yPos + (index * 5));
    }
  });
  
  yPos += customerDetails.length * 5 + 15;
  
  // Items Table
  const tableColumns = language === 'ar' ? 
    ['المجموع', 'السعر', 'الكمية', 'الوصف'] : 
    ['Description', 'Quantity', 'Price', 'Total'];
  
  const tableRows = invoice.items.map(item => {
    const itemName = language === 'ar' ? item.name : (item.nameEn || item.name);
    return language === 'ar' ? 
      [formatCurrency(item.total), formatCurrency(item.price), item.quantity.toString(), itemName] :
      [itemName, item.quantity.toString(), formatCurrency(item.price), formatCurrency(item.total)];
  });
  
  doc.autoTable({
    startY: yPos,
    head: [tableColumns],
    body: tableRows,
    theme: 'grid',
    headStyles: {
      fillColor: primaryColor,
      textColor: [255, 255, 255],
      fontSize: 10,
      fontStyle: 'bold',
      halign: isRTL ? 'right' : 'left'
    },
    bodyStyles: {
      fontSize: 9,
      halign: isRTL ? 'right' : 'left'
    },
    columnStyles: language === 'ar' ? {
      0: { halign: 'right' }, // Total
      1: { halign: 'right' }, // Price
      2: { halign: 'center' }, // Quantity
      3: { halign: 'right' }   // Description
    } : {
      0: { halign: 'left' },   // Description
      1: { halign: 'center' }, // Quantity
      2: { halign: 'right' },  // Price
      3: { halign: 'right' }   // Total
    },
    margin: { left: margin, right: margin },
    tableWidth: 'auto'
  });
  
  // Get the final Y position after the table
  yPos = doc.lastAutoTable.finalY + 20;
  
  // Totals Section
  const totalsWidth = 80;
  const totalsX = pageWidth - margin - totalsWidth;
  
  // Totals background
  doc.setFillColor(248, 250, 252);
  doc.rect(totalsX, yPos, totalsWidth, 40, 'F');
  doc.setDrawColor(...secondaryColor);
  doc.rect(totalsX, yPos, totalsWidth, 40);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  
  const totals = [
    { 
      label: language === 'ar' ? 'المجموع الفرعي:' : 'Subtotal:', 
      value: formatCurrency(invoice.subtotal) 
    },
    { 
      label: language === 'ar' ? 'الضريبة:' : 'Tax:', 
      value: formatCurrency(invoice.tax || 0) 
    },
    { 
      label: language === 'ar' ? 'إجمالي الربح:' : 'Total Profit:', 
      value: formatCurrency(invoice.totalProfit),
      color: [16, 185, 129]
    }
  ];
  
  totals.forEach((total, index) => {
    if (total.color) {
      doc.setTextColor(...total.color);
    } else {
      doc.setTextColor(0, 0, 0);
    }
    
    if (isRTL) {
      doc.text(total.label, totalsX + totalsWidth - 5, yPos + 8 + (index * 6), { align: 'right' });
      doc.text(total.value, totalsX + 40, yPos + 8 + (index * 6), { align: 'right' });
    } else {
      doc.text(total.label, totalsX + 5, yPos + 8 + (index * 6));
      doc.text(total.value, totalsX + totalsWidth - 5, yPos + 8 + (index * 6), { align: 'right' });
    }
  });
  
  // Grand Total
  yPos += 45;
  doc.setFillColor(...accentColor);
  doc.rect(totalsX, yPos, totalsWidth, 12, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  
  const grandTotalLabel = language === 'ar' ? 'الإجمالي:' : 'TOTAL:';
  const grandTotalValue = formatCurrency(invoice.total);
  
  if (isRTL) {
    doc.text(grandTotalLabel, totalsX + totalsWidth - 5, yPos + 8, { align: 'right' });
    doc.text(grandTotalValue, totalsX + 40, yPos + 8, { align: 'right' });
  } else {
    doc.text(grandTotalLabel, totalsX + 5, yPos + 8);
    doc.text(grandTotalValue, totalsX + totalsWidth - 5, yPos + 8, { align: 'right' });
  }
  
  // Payment Information
  if (invoice.paymentMethod) {
    yPos += 25;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    
    const paymentTitle = language === 'ar' ? 'معلومات الدفع:' : 'Payment Information:';
    if (isRTL) {
      doc.text(paymentTitle, pageWidth - margin, yPos, { align: 'right' });
    } else {
      doc.text(paymentTitle, margin, yPos);
    }
    
    yPos += 8;
    doc.setFont('helvetica', 'normal');
    
    const paymentMethodLabel = language === 'ar' ? 'طريقة الدفع:' : 'Payment Method:';
    const paymentMethodValue = language === 'ar' ? 
      (invoice.paymentMethod === 'KHARTOUM_PERSONAL' ? 'حساب شخصي - بنك الخرطوم' :
       invoice.paymentMethod === 'OMDURMAN_PERSONAL' ? 'حساب شخصي - بنك أمدرمان' :
       invoice.paymentMethod === 'OMDURMAN_COMPANY' ? 'حساب الشركة - بنك أمدرمان' :
       'نقداً') : invoice.paymentMethod;
    
    if (isRTL) {
      doc.text(`${paymentMethodLabel} ${paymentMethodValue}`, pageWidth - margin, yPos, { align: 'right' });
    } else {
      doc.text(`${paymentMethodLabel} ${paymentMethodValue}`, margin, yPos);
    }
    
    if (invoice.paidAmount > 0) {
      yPos += 5;
      const paidAmountText = language === 'ar' ? 
        `المبلغ المدفوع: ${formatCurrency(invoice.paidAmount)}` :
        `Paid Amount: ${formatCurrency(invoice.paidAmount)}`;
      
      if (isRTL) {
        doc.text(paidAmountText, pageWidth - margin, yPos, { align: 'right' });
      } else {
        doc.text(paidAmountText, margin, yPos);
      }
      
      if (invoice.remainingAmount > 0) {
        yPos += 5;
        doc.setTextColor(220, 38, 38); // Red color for remaining amount
        const remainingAmountText = language === 'ar' ? 
          `المبلغ المتبقي: ${formatCurrency(invoice.remainingAmount)}` :
          `Remaining Amount: ${formatCurrency(invoice.remainingAmount)}`;
        
        if (isRTL) {
          doc.text(remainingAmountText, pageWidth - margin, yPos, { align: 'right' });
        } else {
          doc.text(remainingAmountText, margin, yPos);
        }
      }
    }
  }
  
  // Notes
  if (invoice.notes) {
    yPos += 20;
    doc.setTextColor(0, 0, 0);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    
    const notesTitle = language === 'ar' ? 'ملاحظات:' : 'Notes:';
    if (isRTL) {
      doc.text(notesTitle, pageWidth - margin, yPos, { align: 'right' });
    } else {
      doc.text(notesTitle, margin, yPos);
    }
    
    yPos += 8;
    doc.setFont('helvetica', 'normal');
    
    if (isRTL) {
      doc.text(invoice.notes, pageWidth - margin, yPos, { align: 'right', maxWidth: pageWidth - (2 * margin) });
    } else {
      doc.text(invoice.notes, margin, yPos, { maxWidth: pageWidth - (2 * margin) });
    }
  }
  
  // Footer
  const footerY = pageHeight - 30;
  doc.setDrawColor(...secondaryColor);
  doc.line(margin, footerY, pageWidth - margin, footerY);
  
  doc.setTextColor(...secondaryColor);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  
  const footerText = language === 'ar' ? 
    'شكراً لتعاملكم معنا - نظام كيان للإدارة المالية' :
    'Thank you for your business - Kayan Financial Management System';
  
  doc.text(footerText, pageWidth / 2, footerY + 10, { align: 'center' });
  
  return doc;
};

export const downloadInvoicePDF = (invoice, customer, language = 'ar') => {
  const doc = generateInvoicePDF(invoice, customer, language);
  const fileName = `invoice_${invoice.invoiceNumber}.pdf`;
  doc.save(fileName);
};

export const previewInvoicePDF = (invoice, customer, language = 'ar') => {
  const doc = generateInvoicePDF(invoice, customer, language);
  const pdfBlob = doc.output('blob');
  const pdfUrl = URL.createObjectURL(pdfBlob);
  window.open(pdfUrl, '_blank');
};

