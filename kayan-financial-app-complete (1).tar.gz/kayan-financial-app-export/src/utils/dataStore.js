// Local Storage Data Management System

class DataStore {
  constructor() {
    this.initializeData()
  }

  initializeData() {
    // Initialize empty arrays - no sample data
    if (!localStorage.getItem('kayan_products')) {
      this.saveProducts([])
    }

    if (!localStorage.getItem('kayan_customers')) {
      this.saveCustomers([])
    }

    if (!localStorage.getItem('kayan_invoices')) {
      this.saveInvoices([])
    }

    if (!localStorage.getItem('kayan_expenses')) {
      this.saveExpenses([])
    }

    if (!localStorage.getItem('kayan_suppliers')) {
      this.saveSuppliers([])
    }
  }

  // Products Management
  getProducts() {
    return JSON.parse(localStorage.getItem('kayan_products') || '[]')
  }

  saveProducts(products) {
    localStorage.setItem('kayan_products', JSON.stringify(products))
  }

  addProduct(product) {
    const products = this.getProducts()
    const newProduct = {
      ...product,
      id: Date.now(),
      createdAt: new Date().toISOString()
    }
    products.push(newProduct)
    this.saveProducts(products)
    return newProduct
  }

  updateProduct(id, updates) {
    const products = this.getProducts()
    const index = products.findIndex(p => p.id === id)
    if (index !== -1) {
      products[index] = { ...products[index], ...updates }
      this.saveProducts(products)
      return products[index]
    }
    return null
  }

  deleteProduct(id) {
    const products = this.getProducts()
    const filtered = products.filter(p => p.id !== id)
    this.saveProducts(filtered)
  }

  // Customers Management
  getCustomers() {
    return JSON.parse(localStorage.getItem('kayan_customers') || '[]')
  }

  saveCustomers(customers) {
    localStorage.setItem('kayan_customers', JSON.stringify(customers))
  }

  addCustomer(customer) {
    const customers = this.getCustomers()
    const newCustomer = {
      ...customer,
      id: Date.now(),
      createdAt: new Date().toISOString()
    }
    customers.push(newCustomer)
    this.saveCustomers(customers)
    return newCustomer
  }

  updateCustomer(id, updates) {
    const customers = this.getCustomers()
    const index = customers.findIndex(c => c.id === id)
    if (index !== -1) {
      customers[index] = { ...customers[index], ...updates }
      this.saveCustomers(customers)
      return customers[index]
    }
    return null
  }

  deleteCustomer(id) {
    const customers = this.getCustomers()
    const filtered = customers.filter(c => c.id !== id)
    this.saveCustomers(filtered)
  }

  // Invoices Management
  getInvoices() {
    return JSON.parse(localStorage.getItem('kayan_invoices') || '[]')
  }

  saveInvoices(invoices) {
    localStorage.setItem('kayan_invoices', JSON.stringify(invoices))
  }

  addInvoice(invoice) {
    const invoices = this.getInvoices()
    const newInvoice = {
      ...invoice,
      id: Date.now(),
      invoiceNumber: this.generateInvoiceNumber(),
      createdAt: new Date().toISOString()
    }
    invoices.push(newInvoice)
    this.saveInvoices(invoices)
    return newInvoice
  }

  updateInvoice(id, updates) {
    const invoices = this.getInvoices()
    const index = invoices.findIndex(i => i.id === id)
    if (index !== -1) {
      invoices[index] = { ...invoices[index], ...updates }
      this.saveInvoices(invoices)
      return invoices[index]
    }
    return null
  }

  deleteInvoice(id) {
    const invoices = this.getInvoices()
    const filtered = invoices.filter(i => i.id !== id)
    this.saveInvoices(filtered)
  }

  generateInvoiceNumber() {
    const invoices = this.getInvoices()
    const lastNumber = invoices.length > 0 
      ? Math.max(...invoices.map(i => parseInt(i.invoiceNumber.split('-')[1]) || 0))
      : 0
    return `INV-${String(lastNumber + 1).padStart(3, '0')}`
  }

  // Expenses Management
  getExpenses() {
    return JSON.parse(localStorage.getItem('kayan_expenses') || '[]')
  }

  saveExpenses(expenses) {
    localStorage.setItem('kayan_expenses', JSON.stringify(expenses))
  }

  addExpense(expense) {
    const expenses = this.getExpenses()
    const newExpense = {
      ...expense,
      id: Date.now(),
      createdAt: new Date().toISOString()
    }
    expenses.push(newExpense)
    this.saveExpenses(expenses)
    return newExpense
  }

  updateExpense(id, updates) {
    const expenses = this.getExpenses()
    const index = expenses.findIndex(e => e.id === id)
    if (index !== -1) {
      expenses[index] = { ...expenses[index], ...updates }
      this.saveExpenses(expenses)
      return expenses[index]
    }
    return null
  }

  deleteExpense(id) {
    const expenses = this.getExpenses()
    const filtered = expenses.filter(e => e.id !== id)
    this.saveExpenses(filtered)
  }

  // Suppliers Management
  getSuppliers() {
    return JSON.parse(localStorage.getItem('kayan_suppliers') || '[]')
  }

  saveSuppliers(suppliers) {
    localStorage.setItem('kayan_suppliers', JSON.stringify(suppliers))
  }

  addSupplier(supplier) {
    const suppliers = this.getSuppliers()
    const newSupplier = {
      ...supplier,
      id: Date.now(),
      createdAt: new Date().toISOString()
    }
    suppliers.push(newSupplier)
    this.saveSuppliers(suppliers)
    return newSupplier
  }

  updateSupplier(id, updates) {
    const suppliers = this.getSuppliers()
    const index = suppliers.findIndex(s => s.id === id)
    if (index !== -1) {
      suppliers[index] = { ...suppliers[index], ...updates }
      this.saveSuppliers(suppliers)
      return suppliers[index]
    }
    return null
  }

  deleteSupplier(id) {
    const suppliers = this.getSuppliers()
    const filtered = suppliers.filter(s => s.id !== id)
    this.saveSuppliers(filtered)
  }

  // Analytics
  getAnalytics() {
    const invoices = this.getInvoices()
    const customers = this.getCustomers()
    const expenses = this.getExpenses()
    
    const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total, 0)
    const totalProfit = invoices.reduce((sum, inv) => sum + inv.totalProfit, 0)
    const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0)
    const netProfit = totalProfit - totalExpenses
    
    return {
      totalInvoices: invoices.length,
      totalCustomers: customers.length,
      totalRevenue,
      totalProfit,
      totalExpenses,
      netProfit,
      paidInvoices: invoices.filter(i => i.paymentStatus === 'paid').length,
      partialInvoices: invoices.filter(i => i.paymentStatus === 'partial').length,
      unpaidInvoices: invoices.filter(i => i.paymentStatus === 'unpaid').length
    }
  }

  getCustomerAnalytics(customerId) {
    const invoices = this.getInvoices().filter(i => i.customerId === customerId)
    const totalAmount = invoices.reduce((sum, inv) => sum + inv.total, 0)
    const totalProfit = invoices.reduce((sum, inv) => sum + inv.totalProfit, 0)
    
    return {
      totalInvoices: invoices.length,
      totalAmount,
      totalProfit,
      invoices: invoices.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    }
  }

  getMonthlyData() {
    const invoices = this.getInvoices()
    const expenses = this.getExpenses()
    const monthlyData = {}

    // Process invoices
    invoices.forEach(invoice => {
      const month = new Date(invoice.createdAt).toISOString().slice(0, 7) // YYYY-MM
      if (!monthlyData[month]) {
        monthlyData[month] = { revenue: 0, profit: 0, expenses: 0 }
      }
      monthlyData[month].revenue += invoice.total
      monthlyData[month].profit += invoice.totalProfit
    })

    // Process expenses
    expenses.forEach(expense => {
      const month = new Date(expense.date).toISOString().slice(0, 7) // YYYY-MM
      if (!monthlyData[month]) {
        monthlyData[month] = { revenue: 0, profit: 0, expenses: 0 }
      }
      monthlyData[month].expenses += expense.amount
    })

    return monthlyData
  }
}

export const dataStore = new DataStore()

