import { createContext, useContext, useState, useEffect } from 'react'

const LanguageContext = createContext()

export const useLanguage = () => {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}

export const LanguageProvider = ({ children }) => {
  const [language, setLanguage] = useState(() => {
    return localStorage.getItem('language') || 'ar'
  })

  const [currency, setCurrency] = useState(() => {
    return localStorage.getItem('currency') || 'SDG'
  })

  useEffect(() => {
    localStorage.setItem('language', language)
    localStorage.setItem('currency', currency)
    
    // Update document direction
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr'
    document.documentElement.lang = language
  }, [language, currency])

  const toggleLanguage = () => {
    const newLanguage = language === 'ar' ? 'en' : 'ar'
    setLanguage(newLanguage)
    
    // Auto-update currency based on language
    if (newLanguage === 'ar') {
      setCurrency('SDG')
    } else {
      setCurrency('USD')
    }
  }

  const formatCurrency = (amount, customCurrency = null) => {
    const curr = customCurrency || currency
    const lang = language === 'ar' ? 'ar-SD' : 'en-US'
    
    if (curr === 'SDG') {
      return new Intl.NumberFormat(lang, {
        style: 'currency',
        currency: 'USD', // Using USD format but displaying as SDG
        minimumFractionDigits: 2
      }).format(amount).replace('$', language === 'ar' ? 'ج.س.' : 'SDG')
    } else {
      return new Intl.NumberFormat(lang, {
        style: 'currency',
        currency: curr,
        minimumFractionDigits: 2
      }).format(amount)
    }
  }

  const formatNumber = (number) => {
    const lang = language === 'ar' ? 'ar-SD' : 'en-US'
    return new Intl.NumberFormat(lang).format(number)
  }

  const formatDate = (date) => {
    const lang = language === 'ar' ? 'ar-SD' : 'en-US'
    return new Intl.DateTimeFormat(lang, {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(new Date(date))
  }

  const value = {
    language,
    currency,
    setLanguage,
    setCurrency,
    toggleLanguage,
    formatCurrency,
    formatNumber,
    formatDate,
    isRTL: language === 'ar'
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  )
}

